# LocalCast & Transfer

**LocalCast & Transfer** is a high-performance, completely offline, zero-cloud local network file transfer and media casting application for Android, Smart TVs, and PCs.

---

## 🚀 Core Features

- **Offline File Transfer**: Stream large files across Wi-Fi or Mobile Hotspot at native network speeds without uploading anything to the internet.
- **End-to-End SHA-256 Checksums**: True streaming cryptographic integrity verification ensuring received files are identical to originals.
- **Resumable Transfers**: Strict offset-validated chunked transfers with `409 Conflict` mismatch protection preventing file corruption.
- **Built-in Web Receiver**: Built-in HTTP server (`port 8765`) serves a modern, responsive web receiver allowing any PC, Mac, Linux, or Smart TV browser to receive files and media without installing extra apps.
- **mDNS / NSD Discovery**: Automatic zero-configuration peer discovery on local subnets with manual IP fallback.
- **Material Design 3 Interface**: Modern Bento Grid layout with real-time transfer telemetry (progress, MB/s, ETA) and edge-to-edge support.
- **Local Persistence**: Powered by Android Room database with versioned migrations for transfer history and paired devices.

---

## 🔒 Privacy & Offline Architecture

LocalCast & Transfer runs **100% on your local private network**:
- **No external accounts or logins**
- **No cloud servers or third-party relays**
- **No API keys or cloud dependencies**
- **No analytics or tracking telemetry**

---

## 🛠️ Technology Stack

- **Platform**: Android (Kotlin, minSdk 26, targetSdk 35)
- **UI Framework**: Jetpack Compose with Material 3
- **Networking**: Kotlin Coroutines, Java Sockets, HTTP/1.1 Engine, mDNS / NSD
- **Storage & Database**: Android Room (`TransferDao`, `PairedDeviceDao`) with automated migrations
- **Asynchronous Architecture**: StateFlow, SharedFlow, Dispatchers.IO streaming pipelines

---

## 📦 Building & Testing

To build the APK:
```bash
./gradlew assembleDebug
```

To run the local unit and protocol test suite:
```bash
./gradlew testDebugUnitTest
```
