package com.localcast.transfer

import com.localcast.transfer.model.Capability
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.DeviceType
import com.localcast.transfer.network.protocol.LocalCastProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun protocolHelloMessage_createsAndParsesValidJson() {
        val device = Device(
            deviceId = "dev_123",
            deviceName = "Test Phone",
            deviceType = DeviceType.PHONE,
            ipAddress = "192.168.1.50",
            port = 8765,
            capabilities = listOf(Capability.FILE_TRANSFER, Capability.VIDEO_STREAM)
        )

        val jsonStr = LocalCastProtocol.createHelloMessage(device)
        assertNotNull(jsonStr)

        val message = LocalCastProtocol.parseMessage(jsonStr)
        assertNotNull(message)
        assertEquals("HELLO", message?.type)
        assertEquals("dev_123", message?.deviceId)
        assertEquals("Test Phone", message?.deviceName)
        assertEquals("PHONE", message?.deviceType)
    }
}
