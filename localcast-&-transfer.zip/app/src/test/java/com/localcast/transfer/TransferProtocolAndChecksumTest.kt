package com.localcast.transfer

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.localcast.transfer.db.AppDatabase
import com.localcast.transfer.db.MIGRATION_1_2
import com.localcast.transfer.db.PairedDeviceEntity
import com.localcast.transfer.db.TransferEntity
import com.localcast.transfer.identity.DeviceIdentityRepository
import com.localcast.transfer.model.Capability
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.DeviceType
import com.localcast.transfer.network.protocol.LocalCastProtocol
import com.localcast.transfer.network.server.LocalHttpServer
import com.localcast.transfer.util.ChecksumUtil
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TransferProtocolAndChecksumTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun checksumUtil_calculatesCorrectSha256ForKnownData() {
        val input = "Hello LocalCast File Transfer!".toByteArray(Charsets.UTF_8)
        val expectedDigest = MessageDigest.getInstance("SHA-256").digest(input)
        val expectedHex = ChecksumUtil.bytesToHex(expectedDigest)

        val computedHex = ChecksumUtil.calculateSha256(ByteArrayInputStream(input))
        assertEquals(expectedHex, computedHex)
    }

    @Test
    fun checksumUtil_calculatesCorrectSha256ForFile() {
        val tempFile = File(context.cacheDir, "test_sha256.tmp")
        val content = "A".repeat(100_000).toByteArray(Charsets.UTF_8)
        FileOutputStream(tempFile).use { it.write(content) }

        val computedChecksum = ChecksumUtil.calculateSha256(tempFile)
        assertNotNull(computedChecksum)
        assertEquals(64, computedChecksum.length) // 64 hex characters for SHA-256

        // Checksum of modified file differs
        FileOutputStream(tempFile).use { it.write("B".repeat(100_000).toByteArray(Charsets.UTF_8)) }
        val modifiedChecksum = ChecksumUtil.calculateSha256(tempFile)
        assertNotEquals(computedChecksum, modifiedChecksum)

        tempFile.delete()
    }

    @Test
    fun resumeOffsetValidation_logicEnsuresNoCorruption() {
        val targetDir = File(context.cacheDir, "received_transfers_test")
        targetDir.mkdirs()
        val partFile = File(targetDir, "test_transfer.part")

        // 1. Initial write of 1000 bytes
        val chunk1 = ByteArray(1000) { 1 }
        FileOutputStream(partFile, false).use { it.write(chunk1) }
        assertEquals(1000L, partFile.length())

        // 2. Exact match resume offset (1000) succeeds and appends
        val resumeOffset = 1000L
        val isValidResume = partFile.exists() && partFile.length() == resumeOffset
        assertTrue("Resume offset matching existing part length must be valid", isValidResume)

        val chunk2 = ByteArray(500) { 2 }
        FileOutputStream(partFile, true).use { it.write(chunk2) }
        assertEquals(1500L, partFile.length())

        // 3. Mismatched resume offset (e.g., 500 when file is 1500) is rejected
        val badOffset = 500L
        val isMismatched = partFile.exists() && partFile.length() != badOffset
        assertTrue("Resume offset mismatch must trigger 409 Conflict rejection", isMismatched)

        // 4. Fresh start (offset 0) resets file
        val resetOffset = 0L
        if (resetOffset == 0L && partFile.exists()) {
            partFile.delete()
        }
        assertFalse(partFile.exists())

        targetDir.deleteRecursively()
    }

    @Test
    fun databaseOperations_andPairedDeviceEntityWithoutPairingCode() = runBlocking {
        val inMemoryDb = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val pairedDevice = PairedDeviceEntity(
            deviceId = "dev_tv_livingroom",
            deviceName = "Smart TV",
            deviceType = "TV",
            ipAddress = "192.168.1.120",
            port = 8765,
            isTrusted = true
        )

        inMemoryDb.pairedDeviceDao().insertPairedDevice(pairedDevice)
        val loaded = inMemoryDb.pairedDeviceDao().getPairedDeviceById("dev_tv_livingroom")
        assertNotNull(loaded)
        assertEquals("Smart TV", loaded?.deviceName)
        assertEquals("192.168.1.120", loaded?.ipAddress)

        val transfer = TransferEntity(
            id = "tf_1",
            fileName = "movie.mp4",
            fileSize = 104857600L,
            mimeType = "video/mp4",
            uriString = "file:///data/movie.mp4",
            direction = "SEND",
            bytesTransferred = 104857600L,
            status = "COMPLETED",
            targetDeviceName = "Smart TV",
            targetDeviceIp = "192.168.1.120",
            checksum = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        )
        inMemoryDb.transferDao().insertTransfer(transfer)

        val transfers = inMemoryDb.transferDao().getAllTransfers().first()
        assertEquals(1, transfers.size)
        assertEquals("movie.mp4", transfers[0].fileName)
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", transfers[0].checksum)

        inMemoryDb.close()
    }

    @Test
    fun protocolHelloMessage_createsAndParsesValidJson() {
        val device = Device(
            deviceId = "dev_123",
            deviceName = "Test Phone",
            deviceType = DeviceType.PHONE,
            ipAddress = "192.168.1.50",
            port = 8765,
            capabilities = listOf(Capability.FILE_TRANSFER, Capability.VIDEO_STREAM)
        )

        val jsonStr = LocalCastProtocol.createHelloMessage(device)
        assertNotNull(jsonStr)

        val message = LocalCastProtocol.parseMessage(jsonStr)
        assertNotNull(message)
        assertEquals("HELLO", message?.type)
        assertEquals("dev_123", message?.deviceId)
        assertEquals("Test Phone", message?.deviceName)
        assertEquals("PHONE", message?.deviceType)
    }

    @Test
    fun deviceIdentityRepository_generatesAndValidatesTemporaryPin() {
        val repo = DeviceIdentityRepository(context)
        val pin = repo.generatePairingPin()
        assertEquals(6, pin.length)
        assertTrue(pin.all { it.isDigit() })

        // Verification success
        val verified = repo.verifyPairingPin(pin)
        assertTrue(verified)

        // Single-use: immediately invalid on second try
        val secondTry = repo.verifyPairingPin(pin)
        assertFalse(secondTry)
    }

    @Test
    fun protocolPhase2_deviceInfoSerializationAndParsing() {
        val device = Device(
            deviceId = "dev_tv_456",
            deviceName = "Living Room Android TV",
            deviceType = DeviceType.SMART_TV,
            ipAddress = "192.168.1.180",
            port = 8765,
            protocolVersion = 1,
            capabilities = listOf(
                Capability.FILE_TRANSFER,
                Capability.VIDEO_STREAM,
                Capability.AUDIO_STREAM,
                Capability.PLAYBACK_CONTROL
            )
        )

        val json = LocalCastProtocol.createDeviceInfoJson(
            device = device,
            isPaired = true,
            activeMediaId = "media_123",
            activeTitle = "Summer Vacation.mp4",
            activeMime = "video/mp4",
            playbackState = com.localcast.transfer.model.ReceiverPlaybackState.PLAYING
        )

        assertEquals(1, json.getInt("protocolVersion"))
        assertEquals("DEVICE_INFO", json.getString("type"))
        assertEquals("dev_tv_456", json.getString("deviceId"))
        assertEquals("Living Room Android TV", json.getString("deviceName"))
        assertEquals("SMART_TV", json.getString("deviceType"))
        assertTrue(json.getBoolean("isPaired"))
        assertEquals("PLAYING", json.getString("receiverState"))

        val parsedDevice = LocalCastProtocol.parseDeviceInfo(json, "192.168.1.180", 8765)
        org.junit.Assert.assertNotNull(parsedDevice)
        assertEquals("dev_tv_456", parsedDevice!!.deviceId)
        assertEquals("Living Room Android TV", parsedDevice.deviceName)
        assertEquals(DeviceType.SMART_TV, parsedDevice.deviceType)
        assertTrue(parsedDevice.capabilities.contains(Capability.PLAYBACK_CONTROL))
    }

    @Test
    fun protocolPhase2_pairRequestAndVerifyPayloads() {
        val reqJson = LocalCastProtocol.createPairRequestJson("sender_client_789", "Pixel 9 Pro")
        assertEquals("PAIR_REQUEST", reqJson.getString("type"))
        assertEquals("sender_client_789", reqJson.getString("deviceId"))
        assertEquals("Pixel 9 Pro", reqJson.getString("deviceName"))

        val verifyJson = LocalCastProtocol.createPairVerifyJson("sess_abc", "123456", "sender_client_789", "Pixel 9 Pro")
        assertEquals("PAIR_VERIFY", verifyJson.getString("type"))
        assertEquals("sess_abc", verifyJson.getString("sessionId"))
        assertEquals("123456", verifyJson.getString("pin"))
    }

    @Test
    fun protocolPhase2_transferNegotiationAndControlCommand() {
        val transferReq = LocalCastProtocol.createTransferRequestJson(
            transferId = "tf_999",
            fileName = "document.pdf",
            fileSize = 204800L,
            mimeType = "application/pdf",
            checksum = "abcdef1234567890",
            supportsResume = true
        )
        assertEquals("TRANSFER_REQUEST", transferReq.getString("type"))
        assertEquals("tf_999", transferReq.getString("transferId"))
        assertEquals(204800L, transferReq.getLong("fileSize"))
        assertTrue(transferReq.getBoolean("supportsResume"))

        val controlJson = LocalCastProtocol.createControlCommandJson(
            command = com.localcast.transfer.model.PlaybackControlCommand.PLAY,
            positionMs = 15000L,
            volume = 0.85f
        )
        assertEquals("CONTROL_COMMAND", controlJson.getString("type"))
        assertEquals("PLAY", controlJson.getString("command"))
        assertEquals(15000L, controlJson.getLong("positionMs"))
        assertEquals(0.85, controlJson.getDouble("volume"), 0.01)
    }
}
