package com.localcast.transfer.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.localcast.transfer.db.AppDatabase
import com.localcast.transfer.db.PairedDeviceEntity
import com.localcast.transfer.identity.DeviceIdentityRepository
import com.localcast.transfer.media.MediaStreamingManager
import com.localcast.transfer.model.CastingMediaItem
import com.localcast.transfer.model.CastingSession
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.NetworkStatus
import com.localcast.transfer.model.PlaybackControlCommand
import com.localcast.transfer.model.TransferItem
import com.localcast.transfer.network.discovery.LocalDiscoveryManager
import com.localcast.transfer.network.discovery.NetworkInfoProvider
import com.localcast.transfer.network.protocol.LocalCastClient
import com.localcast.transfer.network.server.LocalHttpServer
import com.localcast.transfer.service.LocalCastForegroundService
import com.localcast.transfer.transfer.TransferManager
import com.localcast.transfer.transfer.TransferRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

enum class NavigationTab {
    HOME,
    DEVICES,
    TRANSFER,
    CAST,
    SETTINGS
}

data class MainUiState(
    val activeTab: NavigationTab = NavigationTab.HOME,
    val networkStatus: NetworkStatus = NetworkStatus(),
    val isDiscovering: Boolean = false,
    val discoveredDevices: List<Device> = emptyList(),
    val pairedDevices: List<PairedDeviceEntity> = emptyList(),
    val transfers: List<TransferItem> = emptyList(),
    val castingSession: CastingSession = CastingSession(),
    val webReceiverUrl: String = "http://127.0.0.1:8765",
    val pairingPin: String = "000000",
    val selectedDevice: Device? = null,
    val isServerRunning: Boolean = false,
    val statusMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val deviceIdentityRepository = DeviceIdentityRepository(application)
    private val db = AppDatabase.getInstance(application)
    private val transferRepository = TransferRepository(db.transferDao())
    val transferManager = TransferManager(application, transferRepository)

    val discoveryManager = LocalDiscoveryManager(application, deviceIdentityRepository)
    val networkInfoProvider = NetworkInfoProvider(application)

    val client = LocalCastClient(application)

    val mediaStreamingManager: MediaStreamingManager = MediaStreamingManager(
        context = application,
        httpServerProvider = { httpServer },
        networkInfoProvider = networkInfoProvider
    )

    val httpServer: LocalHttpServer = LocalHttpServer(
        context = application,
        deviceIdentityRepository = deviceIdentityRepository,
        port = 8765,
        onFileReceived = { receivedItem ->
            transferManager.registerReceivedFile(receivedItem)
        },
        onDevicePaired = { device ->
            pairDevice(device)
        },
        onDeviceUnpaired = { deviceId ->
            unpairDevice(deviceId)
        },
        onPlaybackControl = { cmd, pos, vol ->
            mediaStreamingManager.handleRemoteControl(cmd, pos, vol)
        }
    )

    private val _activeTab = MutableStateFlow(NavigationTab.HOME)
    private val _selectedDevice = MutableStateFlow<Device?>(null)
    private val _statusMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<MainUiState> = combine(
        _activeTab,
        discoveryManager.networkStatus,
        discoveryManager.isDiscovering,
        discoveryManager.discoveredDevicesList,
        transferRepository.allTransfers,
        db.pairedDeviceDao().getAllPairedDevices(),
        mediaStreamingManager.castingSession,
        _selectedDevice,
        _statusMessage
    ) { args: Array<Any?> ->
        val activeTab = args[0] as NavigationTab
        val networkStatus = args[1] as NetworkStatus
        val isDiscovering = args[2] as Boolean
        @Suppress("UNCHECKED_CAST")
        val discovered = args[3] as List<Device>
        @Suppress("UNCHECKED_CAST")
        val transfers = args[4] as List<TransferItem>
        @Suppress("UNCHECKED_CAST")
        val paired = args[5] as List<PairedDeviceEntity>
        val casting = args[6] as CastingSession
        val selected = args[7] as Device?
        val msg = args[8] as String?

        val webUrl = "http://${networkStatus.ipAddress}:8765"
        MainUiState(
            activeTab = activeTab,
            networkStatus = networkStatus,
            isDiscovering = isDiscovering,
            discoveredDevices = discovered,
            pairedDevices = paired,
            transfers = transfers,
            castingSession = casting,
            webReceiverUrl = webUrl,
            pairingPin = deviceIdentityRepository.getPairingPinForDisplay(),
            selectedDevice = selected,
            isServerRunning = httpServer.isRunning(),
            statusMessage = msg
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MainUiState()
    )

    init {
        // Start Local HTTP server and discovery (Foreground service only runs during active transfers)
        viewModelScope.launch {
            httpServer.start()
            discoveryManager.startDiscovery(8765)
        }
    }

    fun setTab(tab: NavigationTab) {
        _activeTab.value = tab
    }

    fun selectDevice(device: Device?) {
        _selectedDevice.value = device
    }

    fun addManualDevice(ip: String, name: String = "Manual Device") {
        val device = discoveryManager.addManualDevice(ip, 8765, name)
        _selectedDevice.value = device
        showStatus("Added manual device: ${device.deviceName} ($ip)")
    }

    fun startFileTransfer(device: Device, fileName: String, fileSize: Long, mimeType: String, uriString: String) {
        transferManager.enqueueSendFile(
            device = device,
            fileName = fileName,
            fileSize = fileSize,
            mimeType = mimeType,
            uriString = uriString
        )
        _activeTab.value = NavigationTab.TRANSFER
        showStatus("Queued $fileName for transfer to ${device.deviceName}")
    }

    fun pauseTransfer(id: String) {
        transferManager.pauseTransfer(id)
        showStatus("Transfer paused")
    }

    fun resumeTransfer(id: String) {
        transferManager.resumeTransfer(id)
        showStatus("Transfer resumed")
    }

    fun cancelTransfer(id: String) {
        transferManager.cancelTransfer(id)
        showStatus("Transfer cancelled")
    }

    fun startCasting(mediaItem: CastingMediaItem, targetDevice: Device, file: File? = null, uri: Uri? = null) {
        mediaStreamingManager.startCasting(mediaItem, targetDevice, file, uri)
        _activeTab.value = NavigationTab.CAST
        showStatus("Casting ${mediaItem.title} to ${targetDevice.deviceName}")
    }

    fun stopCasting() {
        mediaStreamingManager.stopCasting()
        showStatus("Casting stopped")
    }

    fun pairDevice(device: Device) {
        viewModelScope.launch {
            db.pairedDeviceDao().insertPairedDevice(
                PairedDeviceEntity(
                    deviceId = device.deviceId,
                    deviceName = device.deviceName,
                    deviceType = device.deviceType.name,
                    ipAddress = device.ipAddress,
                    port = device.port
                )
            )
            showStatus("Paired with ${device.deviceName}")
        }
    }

    fun unpairDevice(deviceId: String) {
        viewModelScope.launch {
            db.pairedDeviceDao().deletePairedDevice(deviceId)
            showStatus("Device unpaired")
        }
    }

    fun initiateRemotePairing(
        device: Device,
        onSessionCreated: (sessionId: String) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val challenge = client.requestPairing(
                device = device,
                senderDeviceId = deviceIdentityRepository.deviceId,
                senderName = deviceIdentityRepository.deviceName
            )
            if (challenge.success) {
                onSessionCreated(challenge.sessionId)
            } else {
                onError(challenge.errorMessage ?: "Pairing request failed")
            }
        }
    }

    fun submitPairingPin(
        device: Device,
        sessionId: String,
        pin: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val verify = client.verifyPairingPin(
                device = device,
                sessionId = sessionId,
                pin = pin,
                senderDeviceId = deviceIdentityRepository.deviceId,
                senderName = deviceIdentityRepository.deviceName
            )
            if (verify.success && verify.isPaired) {
                pairDevice(device.copy(isPaired = true))
                onSuccess()
            } else {
                onError(verify.errorMessage ?: "Incorrect PIN or pairing session expired")
            }
        }
    }

    fun sendRemoteControlCommand(
        command: PlaybackControlCommand,
        positionMs: Long = 0L,
        volume: Float = 1.0f
    ) {
        val target = uiState.value.castingSession.targetDevice
        mediaStreamingManager.handleRemoteControl(command, positionMs, volume)
        if (target != null) {
            viewModelScope.launch {
                client.sendControlCommand(target, command, positionMs, volume)
            }
        }
    }

    fun refreshPairingPin() {
        val newPin = deviceIdentityRepository.generatePairingPin()
        showStatus("New pairing PIN generated: $newPin")
    }

    fun clearHistory() {
        viewModelScope.launch {
            transferRepository.clearHistory()
            showStatus("Transfer history cleared")
        }
    }

    fun showStatus(msg: String) {
        _statusMessage.value = msg
        viewModelScope.launch {
            kotlinx.coroutines.delay(3500)
            if (_statusMessage.value == msg) {
                _statusMessage.value = null
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        httpServer.stop()
        discoveryManager.stopDiscovery()
    }
}
