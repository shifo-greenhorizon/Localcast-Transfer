package com.localcast.transfer.util

import android.content.Context
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.security.MessageDigest

object ChecksumUtil {
    private const val TAG = "LocalCast/Checksum"
    private const val BUFFER_SIZE = 32768

    fun calculateSha256(inputStream: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER_SIZE)
        var bytesRead: Int
        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
            digest.update(buffer, 0, bytesRead)
        }
        return bytesToHex(digest.digest())
    }

    fun calculateSha256(file: File): String {
        return FileInputStream(file).use { fis ->
            calculateSha256(fis)
        }
    }

    fun calculateSha256(context: Context, uriString: String): String? {
        return try {
            if (uriString.startsWith("file://")) {
                val path = Uri.parse(uriString).path ?: return null
                calculateSha256(File(path))
            } else {
                val uri = Uri.parse(uriString)
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    calculateSha256(inputStream)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to calculate SHA-256 for URI: $uriString", e)
            null
        }
    }

    fun bytesToHex(bytes: ByteArray): String {
        val hexArray = "0123456789abcdef".toCharArray()
        val hexChars = CharArray(bytes.size * 2)
        for (j in bytes.indices) {
            val v = bytes[j].toInt() and 0xFF
            hexChars[j * 2] = hexArray[v ushr 4]
            hexChars[j * 2 + 1] = hexArray[v and 0x0F]
        }
        return String(hexChars)
    }
}
