package com.localcast.transfer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localcast.transfer.model.Device
import com.localcast.transfer.ui.MainUiState
import com.localcast.transfer.ui.components.DeviceItemRow
import com.localcast.transfer.ui.theme.BentoAccentLavender
import com.localcast.transfer.ui.theme.BentoCardBg
import com.localcast.transfer.ui.theme.BentoCardBorder
import com.localcast.transfer.ui.theme.BentoDarkPurple
import com.localcast.transfer.ui.theme.BentoMintGreen
import com.localcast.transfer.ui.theme.TextMuted
import com.localcast.transfer.ui.theme.TextPrimary
import com.localcast.transfer.ui.theme.TextSecondary

@Composable
fun DevicesScreen(
    state: MainUiState,
    onSelectDevice: (Device) -> Unit,
    onAddManualDevice: (ip: String, name: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var ipInput by remember { mutableStateOf("") }
    var nameInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("devices_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Add Connection by IP",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = TextPrimary
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = BentoCardBg),
                border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Connect directly to a computer, TV, or phone IP",
                        fontSize = 13.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = ipInput,
                        onValueChange = { ipInput = it },
                        label = { Text("IP Address (e.g. 192.168.1.50)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ip_input_field"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BentoAccentLavender,
                            unfocusedBorderColor = BentoCardBorder,
                            focusedLabelColor = BentoAccentLavender,
                            unfocusedLabelColor = TextMuted,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Device Label (Optional)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("device_label_input_field"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BentoAccentLavender,
                            unfocusedBorderColor = BentoCardBorder,
                            focusedLabelColor = BentoAccentLavender,
                            unfocusedLabelColor = TextMuted,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (ipInput.isNotBlank()) {
                                onAddManualDevice(
                                    ipInput.trim(),
                                    if (nameInput.isNotBlank()) nameInput.trim() else "Manual Target"
                                )
                                ipInput = ""
                                nameInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BentoAccentLavender),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_ip_device_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add", tint = BentoDarkPurple)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Connect to Device", color = BentoDarkPurple, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Discovered Local Devices",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimary
                )
                Text(
                    text = "${state.discoveredDevices.size} Found",
                    fontSize = 12.sp,
                    color = BentoMintGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (state.discoveredDevices.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BentoCardBg),
                    border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No devices auto-discovered yet",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                    }
                }
            }
        } else {
            items(state.discoveredDevices) { device ->
                DeviceItemRow(
                    device = device,
                    onConnectClick = { onSelectDevice(device) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
