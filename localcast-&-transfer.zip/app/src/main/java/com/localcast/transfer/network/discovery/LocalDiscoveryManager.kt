package com.localcast.transfer.network.discovery

import android.content.Context
import com.localcast.transfer.identity.DeviceIdentityRepository
import com.localcast.transfer.model.Capability
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.DeviceType
import com.localcast.transfer.model.NetworkStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LocalDiscoveryManager(
    private val context: Context,
    private val deviceIdentityRepository: DeviceIdentityRepository
) {

    private val networkInfoProvider = NetworkInfoProvider(context)
    private val nsdDiscovery = NsdDiscovery(context)
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val _networkStatus = MutableStateFlow(networkInfoProvider.getNetworkStatus())
    val networkStatus: StateFlow<NetworkStatus> = _networkStatus.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private val _manualDevices = MutableStateFlow<Map<String, Device>>(emptyMap())

    private val _discoveredDevicesList = MutableStateFlow<List<Device>>(emptyList())
    val discoveredDevicesList: StateFlow<List<Device>> = _discoveredDevicesList.asStateFlow()

    val localDeviceName: String
        get() = deviceIdentityRepository.deviceName

    init {
        // Poll network status every 4 seconds
        scope.launch {
            while (true) {
                _networkStatus.value = networkInfoProvider.getNetworkStatus()
                delay(4000)
            }
        }

        // Combine NSD discovered devices and manually added devices
        scope.launch {
            nsdDiscovery.discoveredDevices.collect { nsdMap ->
                val combined = (nsdMap + _manualDevices.value).values.toList()
                _discoveredDevicesList.value = combined
            }
        }
    }

    fun startDiscovery(port: Int = 8765) {
        if (_isDiscovering.value) return
        _isDiscovering.value = true
        nsdDiscovery.registerService(port, localDeviceName)
        nsdDiscovery.startDiscovery()
    }

    fun stopDiscovery() {
        if (!_isDiscovering.value) return
        _isDiscovering.value = false
        nsdDiscovery.stopDiscovery()
        nsdDiscovery.unregisterService()
    }

    fun addManualDevice(ipAddress: String, port: Int = 8765, name: String = "Manual Connection"): Device {
        val deviceId = "manual_${ipAddress.replace(".", "_")}_$port"
        val device = Device(
            deviceId = deviceId,
            deviceName = name,
            deviceType = DeviceType.WEB_RECEIVER,
            ipAddress = ipAddress,
            port = port,
            capabilities = listOf(
                Capability.FILE_TRANSFER,
                Capability.VIDEO_STREAM,
                Capability.PHOTO_STREAM
            )
        )
        val current = _manualDevices.value.toMutableMap()
        current[deviceId] = device
        _manualDevices.value = current

        val combined = (nsdDiscovery.discoveredDevices.value + _manualDevices.value).values.toList()
        _discoveredDevicesList.value = combined

        return device
    }
}
