package com.localcast.transfer.model

enum class DeviceType {
    ANDROID,
    WEB_RECEIVER,
    DESKTOP_RECEIVER,
    SMART_TV,
    PHONE,
    TABLET,
    COMPUTER,
    DLNA_DEVICE,
    UNKNOWN
}

enum class Capability {
    FILE_TRANSFER,
    VIDEO_STREAM,
    PHOTO_STREAM,
    AUDIO_STREAM,
    PLAYBACK_CONTROL
}

data class Device(
    val deviceId: String,
    val deviceName: String,
    val deviceType: DeviceType = DeviceType.ANDROID,
    val ipAddress: String,
    val port: Int = 8765,
    val capabilities: List<Capability> = listOf(
        Capability.FILE_TRANSFER,
        Capability.VIDEO_STREAM,
        Capability.PHOTO_STREAM,
        Capability.AUDIO_STREAM,
        Capability.PLAYBACK_CONTROL
    ),
    val protocolVersion: Int = 1,
    val isPaired: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)

enum class TransferDirection {
    SEND,
    RECEIVE
}

enum class TransferStatus {
    QUEUED,
    PREPARING,
    OFFERED,
    ACCEPTED,
    CONNECTING,
    TRANSFERRING,
    PAUSED,
    RESUMING,
    VERIFYING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class TransferItem(
    val id: String,
    val fileName: String,
    val fileSize: Long,
    val mimeType: String,
    val uriString: String,
    val direction: TransferDirection,
    val bytesTransferred: Long = 0L,
    val status: TransferStatus = TransferStatus.QUEUED,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = 0L,
    val targetDeviceName: String,
    val targetDeviceIp: String,
    val timestamp: Long = System.currentTimeMillis(),
    val checksum: String? = null,
    val errorMessage: String? = null
) {
    val progress: Float
        get() = if (fileSize > 0) (bytesTransferred.toFloat() / fileSize.toFloat()).coerceIn(0f, 1f) else 0f
}

sealed interface ConnectionState {
    data object Disconnected : ConnectionState
    data object Discovering : ConnectionState
    data class Pairing(val device: Device, val sessionId: String) : ConnectionState
    data class Connecting(val device: Device) : ConnectionState
    data class Connected(val device: Device) : ConnectionState
    data class Failed(val reason: String) : ConnectionState
}

data class NetworkStatus(
    val isWifiConnected: Boolean = false,
    val isHotspotActive: Boolean = false,
    val ipAddress: String = "127.0.0.1",
    val ssid: String = "Disconnected",
    val interfaceName: String = "none",
    val isLocalNetworkReady: Boolean = false
)

enum class PlaybackControlCommand {
    PLAY,
    PAUSE,
    STOP,
    SEEK,
    VOLUME
}

enum class ReceiverPlaybackState {
    IDLE,
    PAIRING,
    READY,
    RECEIVING,
    PLAYING,
    PAUSED,
    STOPPED,
    ERROR
}

data class CastingMediaItem(
    val id: String,
    val title: String,
    val uriString: String,
    val mimeType: String,
    val durationMs: Long = 0L,
    val fileSize: Long = 0L
)

data class CastingSession(
    val isCasting: Boolean = false,
    val currentItem: CastingMediaItem? = null,
    val targetDevice: Device? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val volume: Float = 1.0f,
    val streamUrl: String = "",
    val receiverState: ReceiverPlaybackState = ReceiverPlaybackState.IDLE
)

