package com.localcast.transfer.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transfers")
data class TransferEntity(
    @PrimaryKey
    val id: String,
    val fileName: String,
    val fileSize: Long,
    val mimeType: String,
    val uriString: String,
    val direction: String, // "SEND" or "RECEIVE"
    val bytesTransferred: Long,
    val status: String, // "QUEUED", "CONNECTING", "TRANSFERRING", "PAUSED", "COMPLETED", "FAILED", "CANCELLED"
    val targetDeviceName: String,
    val targetDeviceIp: String,
    val timestamp: Long = System.currentTimeMillis(),
    val checksum: String? = null,
    val errorMessage: String? = null
)

@Entity(tableName = "paired_devices")
data class PairedDeviceEntity(
    @PrimaryKey
    val deviceId: String,
    val deviceName: String,
    val deviceType: String,
    val ipAddress: String,
    val port: Int,
    val isTrusted: Boolean = true,
    val lastConnectedTimestamp: Long = System.currentTimeMillis()
)
