package com.localcast.transfer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val LocalCastDarkColorScheme = darkColorScheme(
    primary = BentoAccentLavender,
    onPrimary = BentoDarkPurple,
    primaryContainer = BentoLavenderLight,
    onPrimaryContainer = BentoDeepPurple,
    secondary = BentoMintGreen,
    onSecondary = BentoDarkBg,
    secondaryContainer = BentoCardBg,
    onSecondaryContainer = TextPrimary,
    tertiary = BentoMintGreen,
    background = BentoDarkBg,
    onBackground = TextPrimary,
    surface = BentoCardBg,
    onSurface = TextPrimary,
    surfaceVariant = BentoCardBorder,
    onSurfaceVariant = TextSecondary,
    outline = BentoCardBorder,
    error = RoseError,
    onError = TextPrimary
)

@Composable
fun LocalCastTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LocalCastDarkColorScheme,
        typography = Typography,
        content = content
    )
}
