package com.localcast.transfer.transfer

import android.content.Context
import android.util.Log
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.DeviceType
import com.localcast.transfer.model.TransferDirection
import com.localcast.transfer.model.TransferItem
import com.localcast.transfer.model.TransferStatus
import com.localcast.transfer.network.protocol.LocalCastClient
import com.localcast.transfer.service.LocalCastForegroundService
import com.localcast.transfer.util.ChecksumUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class TransferManager(
    private val context: Context,
    private val repository: TransferRepository
) {
    private val TAG = "LocalCast/TransferMgr"
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val client = LocalCastClient(context)

    private val activeJobMap = ConcurrentHashMap<String, Job>()
    private val _activeTransfersMap = MutableStateFlow<Map<String, TransferItem>>(emptyMap())

    val activeTransfersList: StateFlow<List<TransferItem>> = _activeTransfersMap
        .map { map -> map.values.sortedByDescending { it.timestamp } }
        .stateIn(scope, SharingStarted.Eagerly, emptyList())

    init {
        scope.launch {
            repository.allTransfers.collect { dbList ->
                val currentMap = _activeTransfersMap.value.toMutableMap()
                dbList.forEach { item ->
                    if (!currentMap.containsKey(item.id)) {
                        currentMap[item.id] = item
                    }
                }
                _activeTransfersMap.value = currentMap
            }
        }
    }

    fun enqueueSendFile(
        device: Device,
        fileName: String,
        fileSize: Long,
        mimeType: String,
        uriString: String
    ): TransferItem {
        val transfer = TransferItem(
            id = UUID.randomUUID().toString(),
            fileName = fileName,
            fileSize = fileSize,
            mimeType = mimeType,
            uriString = uriString,
            direction = TransferDirection.SEND,
            bytesTransferred = 0L,
            status = TransferStatus.QUEUED,
            targetDeviceName = device.deviceName,
            targetDeviceIp = device.ipAddress,
            timestamp = System.currentTimeMillis()
        )

        updateTransferState(transfer)
        startSendTask(device, transfer, resumeOffset = 0L)
        return transfer
    }

    fun registerReceivedFile(item: TransferItem) {
        updateTransferState(item)
    }

    private fun startSendTask(device: Device, initialItem: TransferItem, resumeOffset: Long = 0L) {
        val job = scope.launch {
            var current = initialItem.copy(
                status = if (resumeOffset > 0) TransferStatus.RESUMING else TransferStatus.CONNECTING
            )
            updateTransferState(current)
            checkAndManageForegroundService()

            // Calculate original SHA-256 checksum if not already calculated
            if (current.checksum.isNullOrBlank()) {
                val computedChecksum = ChecksumUtil.calculateSha256(context, current.uriString)
                if (!computedChecksum.isNullOrBlank()) {
                    current = current.copy(checksum = computedChecksum)
                    updateTransferState(current)
                }
            }

            // Negotiate transfer with receiver for resume offset or acceptance
            val negotiation = client.negotiateTransfer(device, current)
            val effectiveOffset = if (negotiation.requiresResume && negotiation.resumeOffset > 0L) {
                negotiation.resumeOffset
            } else {
                resumeOffset
            }

            current = current.copy(
                status = if (effectiveOffset > 0L) TransferStatus.RESUMING else TransferStatus.TRANSFERRING,
                bytesTransferred = effectiveOffset
            )
            updateTransferState(current)

            val result = client.sendFileToDevice(
                device = device,
                transferItem = current,
                resumeOffset = effectiveOffset,
                onProgress = { bytesSent, speedBps, etaSec ->
                    current = current.copy(
                        bytesTransferred = bytesSent,
                        speedBytesPerSec = speedBps,
                        etaSeconds = etaSec,
                        status = TransferStatus.TRANSFERRING
                    )
                    updateTransferState(current)
                }
            )

            if (result.success) {
                current = current.copy(
                    bytesTransferred = current.fileSize,
                    status = TransferStatus.COMPLETED,
                    speedBytesPerSec = 0L,
                    etaSeconds = 0L,
                    checksum = result.checksum ?: current.checksum
                )
            } else {
                val isCancelled = _activeTransfersMap.value[current.id]?.status == TransferStatus.CANCELLED
                val isPaused = _activeTransfersMap.value[current.id]?.status == TransferStatus.PAUSED
                if (!isCancelled && !isPaused) {
                    current = current.copy(
                        status = TransferStatus.FAILED,
                        bytesTransferred = if (result.errorMessage == "RESUME_OFFSET_MISMATCH") 0L else current.bytesTransferred,
                        errorMessage = result.errorMessage ?: "Transfer interrupted"
                    )
                } else {
                    checkAndManageForegroundService()
                    return@launch
                }
            }
            updateTransferState(current)
            activeJobMap.remove(current.id)
            checkAndManageForegroundService()
        }

        activeJobMap[initialItem.id] = job
    }

    fun pauseTransfer(id: String) {
        activeJobMap[id]?.cancel()
        activeJobMap.remove(id)

        val item = _activeTransfersMap.value[id]
        if (item != null && item.status == TransferStatus.TRANSFERRING) {
            val paused = item.copy(
                status = TransferStatus.PAUSED,
                speedBytesPerSec = 0L,
                etaSeconds = 0L
            )
            updateTransferState(paused)
        }
        checkAndManageForegroundService()
    }

    fun resumeTransfer(id: String) {
        val item = _activeTransfersMap.value[id] ?: return
        if (item.status != TransferStatus.PAUSED && item.status != TransferStatus.FAILED) return

        val targetDevice = Device(
            deviceId = "target_${item.targetDeviceIp.replace(".", "_")}",
            deviceName = item.targetDeviceName,
            deviceType = DeviceType.ANDROID,
            ipAddress = item.targetDeviceIp,
            port = 8765
        )

        startSendTask(targetDevice, item, resumeOffset = item.bytesTransferred)
    }

    fun cancelTransfer(id: String) {
        activeJobMap[id]?.cancel()
        activeJobMap.remove(id)

        val item = _activeTransfersMap.value[id]
        if (item != null) {
            val cancelled = item.copy(
                status = TransferStatus.CANCELLED,
                speedBytesPerSec = 0L,
                etaSeconds = 0L
            )
            updateTransferState(cancelled)
        }
        checkAndManageForegroundService()
    }

    private fun updateTransferState(item: TransferItem) {
        val map = _activeTransfersMap.value.toMutableMap()
        map[item.id] = item
        _activeTransfersMap.value = map

        scope.launch {
            repository.saveTransfer(item)
        }
    }

    private fun checkAndManageForegroundService() {
        val hasActiveTransfers = _activeTransfersMap.value.values.any {
            it.status == TransferStatus.TRANSFERRING ||
            it.status == TransferStatus.CONNECTING ||
            it.status == TransferStatus.RESUMING
        }
        if (hasActiveTransfers) {
            try {
                LocalCastForegroundService.startService(context)
            } catch (e: Exception) {
                Log.w(TAG, "Could not start foreground service", e)
            }
        } else {
            try {
                LocalCastForegroundService.stopService(context)
            } catch (e: Exception) {
                Log.w(TAG, "Could not stop foreground service", e)
            }
        }
    }
}
