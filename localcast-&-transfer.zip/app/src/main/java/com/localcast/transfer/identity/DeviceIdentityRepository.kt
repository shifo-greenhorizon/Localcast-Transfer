package com.localcast.transfer.identity

import android.content.Context
import android.os.Build
import android.util.Log
import java.security.SecureRandom
import java.util.UUID

class DeviceIdentityRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("localcast_device_prefs", Context.MODE_PRIVATE)
    private val secureRandom = SecureRandom()

    private val TAG = "LocalCast/DeviceIdentity"

    val deviceId: String
        get() {
            val existing = prefs.getString("persistent_device_id", null)
            if (!existing.isNullOrEmpty()) {
                return existing
            }
            val newId = "dev_" + UUID.randomUUID().toString().replace("-", "").take(12)
            prefs.edit().putString("persistent_device_id", newId).apply()
            Log.i(TAG, "Generated and persisted new Device ID: $newId")
            return newId
        }

    val deviceName: String
        get() {
            val model = Build.MODEL ?: "Android Device"
            return if (model.contains("Android", ignoreCase = true)) model else "LocalCast $model"
        }

    @Volatile
    private var activePairingPin: String = ""
    @Volatile
    private var pinExpiryTimestamp: Long = 0L

    @Synchronized
    fun generatePairingPin(): String {
        val now = System.currentTimeMillis()
        if (activePairingPin.isNotEmpty() && now < pinExpiryTimestamp) {
            return activePairingPin
        }
        val pin = String.format("%06d", secureRandom.nextInt(1000000))
        activePairingPin = pin
        pinExpiryTimestamp = now + 60_000L // 60 seconds validity
        Log.i(TAG, "Generated new temporary pairing PIN (expires in 60s)")
        return pin
    }

    fun getPairingPinForDisplay(): String {
        return generatePairingPin()
    }

    fun verifyPairingPin(pin: String): Boolean {
        val now = System.currentTimeMillis()
        if (now > pinExpiryTimestamp) {
            Log.w(TAG, "Pairing PIN verification failed: PIN expired")
            return false
        }
        val matches = activePairingPin.isNotEmpty() && activePairingPin == pin.trim()
        if (matches) {
            // Expire immediately after single-use
            pinExpiryTimestamp = 0L
            Log.i(TAG, "Pairing PIN verified successfully")
        }
        return matches
    }

    private fun String?.isNull_or_Empty(): Boolean = this == null || this.trim().isEmpty()
}
