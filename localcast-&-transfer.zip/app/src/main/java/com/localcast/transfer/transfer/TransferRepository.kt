package com.localcast.transfer.transfer

import com.localcast.transfer.db.TransferDao
import com.localcast.transfer.db.TransferEntity
import com.localcast.transfer.model.TransferDirection
import com.localcast.transfer.model.TransferItem
import com.localcast.transfer.model.TransferStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TransferRepository(private val transferDao: TransferDao) {

    val allTransfers: Flow<List<TransferItem>> = transferDao.getAllTransfers().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun saveTransfer(item: TransferItem) {
        transferDao.insertTransfer(item.toEntity())
    }

    suspend fun updateTransfer(item: TransferItem) {
        transferDao.updateTransfer(item.toEntity())
    }

    suspend fun deleteTransfer(id: String) {
        transferDao.deleteTransferById(id)
    }

    suspend fun clearHistory() {
        transferDao.clearAllTransfers()
    }

    private fun TransferEntity.toDomain(): TransferItem {
        return TransferItem(
            id = id,
            fileName = fileName,
            fileSize = fileSize,
            mimeType = mimeType,
            uriString = uriString,
            direction = if (direction == "SEND") TransferDirection.SEND else TransferDirection.RECEIVE,
            bytesTransferred = bytesTransferred,
            status = try { TransferStatus.valueOf(status) } catch (e: Exception) { TransferStatus.COMPLETED },
            targetDeviceName = targetDeviceName,
            targetDeviceIp = targetDeviceIp,
            timestamp = timestamp,
            checksum = checksum,
            errorMessage = errorMessage
        )
    }

    private fun TransferItem.toEntity(): TransferEntity {
        return TransferEntity(
            id = id,
            fileName = fileName,
            fileSize = fileSize,
            mimeType = mimeType,
            uriString = uriString,
            direction = direction.name,
            bytesTransferred = bytesTransferred,
            status = status.name,
            targetDeviceName = targetDeviceName,
            targetDeviceIp = targetDeviceIp,
            timestamp = timestamp,
            checksum = checksum,
            errorMessage = errorMessage
        )
    }
}
