package com.localcast.transfer.network.server

import android.content.Context
import android.net.Uri
import android.util.Log
import com.localcast.transfer.identity.DeviceIdentityRepository
import com.localcast.transfer.model.Capability
import com.localcast.transfer.model.CastingMediaItem
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.DeviceType
import com.localcast.transfer.model.PlaybackControlCommand
import com.localcast.transfer.model.ReceiverPlaybackState
import com.localcast.transfer.model.TransferDirection
import com.localcast.transfer.model.TransferItem
import com.localcast.transfer.model.TransferStatus
import com.localcast.transfer.network.protocol.LocalCastProtocol
import com.localcast.transfer.util.ChecksumUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class LocalHttpServer(
    private val context: Context,
    private val deviceIdentityRepository: DeviceIdentityRepository,
    private val port: Int = 8765,
    private val onFileReceived: ((TransferItem) -> Unit)? = null,
    private val onDevicePaired: ((Device) -> Unit)? = null,
    private val onDeviceUnpaired: ((String) -> Unit)? = null,
    private val onPlaybackControl: ((PlaybackControlCommand, Long, Float) -> Unit)? = null
) {
    private val TAG = "LocalCast/HttpServer"
    private var serverSocket: ServerSocket? = null
    @Volatile
    private var isRunning = false
    private var serverScope: CoroutineScope? = null

    // Limit concurrent socket handlers to 12
    private val connectionSemaphore = Semaphore(12)
    private val serverMutex = Mutex()

    // Media resources registered for streaming
    private val registeredMediaMap = ConcurrentHashMap<String, MediaResource>()

    // Active casting info for web receiver
    @Volatile
    var activeCastingItem: CastingMediaItem? = null

    @Volatile
    var activePlaybackState: ReceiverPlaybackState = ReceiverPlaybackState.IDLE

    @Volatile
    var currentPositionMs: Long = 0L

    @Volatile
    var currentVolume: Float = 1.0f

    // Active pairing sessions: sessionId -> timestamp
    private val activePairingSessions = ConcurrentHashMap<String, Long>()

    data class MediaResource(
        val id: String,
        val title: String,
        val mimeType: String,
        val file: File? = null,
        val uri: Uri? = null,
        val contentLength: Long = 0L
    )

    fun registerMedia(mediaItem: CastingMediaItem, file: File? = null, uri: Uri? = null): String {
        val resource = MediaResource(
            id = mediaItem.id,
            title = mediaItem.title,
            mimeType = mediaItem.mimeType,
            file = file,
            uri = uri ?: if (mediaItem.uriString.isNotEmpty()) Uri.parse(mediaItem.uriString) else null,
            contentLength = mediaItem.fileSize
        )
        registeredMediaMap[mediaItem.id] = resource
        activeCastingItem = mediaItem
        activePlaybackState = ReceiverPlaybackState.PLAYING
        return "/media/${mediaItem.id}"
    }

    fun unregisterMedia(mediaId: String) {
        registeredMediaMap.remove(mediaId)
        if (activeCastingItem?.id == mediaId) {
            activeCastingItem = null
            activePlaybackState = ReceiverPlaybackState.IDLE
        }
    }

    suspend fun start() = withContext(Dispatchers.IO) {
        serverMutex.withLock {
            if (isRunning) return@withContext
            try {
                val scope = CoroutineScope(Dispatchers.IO + Job())
                serverScope = scope
                serverSocket = ServerSocket(port).apply {
                    soTimeout = 10000 // 10s accept timeout for non-blocking shutdown
                }
                isRunning = true
                Log.i(TAG, "LocalCast HTTP Server listening on port $port")

                scope.launch {
                    while (isRunning && serverSocket != null && !serverSocket!!.isClosed) {
                        try {
                            val clientSocket = serverSocket!!.accept()
                            scope.launch {
                                connectionSemaphore.withPermit {
                                    handleClientSocket(clientSocket)
                                }
                            }
                        } catch (e: Exception) {
                            if (!isRunning) break
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to bind HTTP server to port $port", e)
                isRunning = false
            }
        }
    }

    @Synchronized
    fun stop() {
        isRunning = false
        try {
            serverSocket?.close()
            serverSocket = null
        } catch (e: Exception) {
            Log.e(TAG, "Error closing server socket", e)
        }
        serverScope?.cancel()
        serverScope = null
        Log.i(TAG, "LocalCast HTTP Server stopped")
    }

    fun isRunning(): Boolean = isRunning

    private suspend fun handleClientSocket(socket: Socket) = withContext(Dispatchers.IO) {
        socket.use { s ->
            try {
                s.soTimeout = 15000 // Socket timeout for client operations
                val input = s.getInputStream()
                val output = s.getOutputStream()

                val requestHeaders = parseHttpRequestHeaders(input) ?: return@use
                val method = requestHeaders["METHOD"] ?: "GET"
                val rawPath = requestHeaders["PATH"] ?: "/"
                val path = rawPath.substringBefore("?")

                Log.d(TAG, "HTTP $method $rawPath")

                when {
                    method == "OPTIONS" -> {
                        sendCorsOptionsResponse(output)
                    }

                    (path == "/" || path == "/receiver") && method == "GET" -> {
                        serveWebReceiverHtml(output)
                    }

                    (path == "/api/v1/device" || path == "/device") && method == "GET" -> {
                        val device = Device(
                            deviceId = deviceIdentityRepository.deviceId,
                            deviceName = deviceIdentityRepository.deviceName,
                            deviceType = DeviceType.ANDROID,
                            ipAddress = s.localAddress?.hostAddress ?: "127.0.0.1",
                            port = port,
                            protocolVersion = LocalCastProtocol.PROTOCOL_VERSION,
                            capabilities = listOf(
                                Capability.FILE_TRANSFER,
                                Capability.VIDEO_STREAM,
                                Capability.PHOTO_STREAM,
                                Capability.AUDIO_STREAM,
                                Capability.PLAYBACK_CONTROL
                            )
                        )
                        val json = LocalCastProtocol.createDeviceInfoJson(
                            device = device,
                            isPaired = false,
                            activeMediaId = activeCastingItem?.id,
                            activeTitle = activeCastingItem?.title,
                            activeMime = activeCastingItem?.mimeType,
                            playbackState = activePlaybackState
                        )
                        sendHttpResponse(output, 200, "OK", "application/json", json.toString().toByteArray())
                    }

                    (path == "/api/v1/pair/request" || path == "/pair/request") && method == "POST" -> {
                        val sessionId = "pair_sess_" + UUID.randomUUID().toString().take(8)
                        activePairingSessions[sessionId] = System.currentTimeMillis() + 60000L
                        // Ensure a temporary pairing PIN is generated/active
                        deviceIdentityRepository.generatePairingPin()

                        val responseJson = JSONObject().apply {
                            put("status", "ok")
                            put("type", LocalCastProtocol.TYPE_PAIR_CHALLENGE)
                            put("protocolVersion", LocalCastProtocol.PROTOCOL_VERSION)
                            put("sessionId", sessionId)
                            put("requiresPin", true)
                            put("expiresInMs", 60000L)
                        }
                        sendHttpResponse(output, 200, "OK", "application/json", responseJson.toString().toByteArray())
                    }

                    (path == "/api/v1/pair/verify" || path == "/pair/verify") && method == "POST" -> {
                        val body = readRequestBodyAsString(input, requestHeaders)
                        val json = if (body.isNotEmpty()) JSONObject(body) else JSONObject()
                        val sessionId = json.optString("sessionId", "")
                        val pin = json.optString("pin", "")
                        val senderDeviceId = json.optString("deviceId", "unknown_client")
                        val senderDeviceName = json.optString("deviceName", "Paired Client")
                        val rawDeviceType = json.optString("deviceType", "ANDROID")

                        val sessionExpiry = activePairingSessions[sessionId] ?: 0L
                        val isSessionValid = sessionId.isNotEmpty() && System.currentTimeMillis() <= sessionExpiry

                        if (isSessionValid && deviceIdentityRepository.verifyPairingPin(pin)) {
                            activePairingSessions.remove(sessionId)

                            val devType = try {
                                DeviceType.valueOf(rawDeviceType.uppercase())
                            } catch (e: Exception) {
                                DeviceType.ANDROID
                            }
                            val clientIp = s.inetAddress?.hostAddress ?: "127.0.0.1"
                            val clientDevice = Device(
                                deviceId = senderDeviceId,
                                deviceName = senderDeviceName,
                                deviceType = devType,
                                ipAddress = clientIp,
                                port = port,
                                isPaired = true
                            )
                            onDevicePaired?.invoke(clientDevice)

                            val successJson = JSONObject().apply {
                                put("status", "ok")
                                put("type", LocalCastProtocol.TYPE_PAIR_RESULT)
                                put("paired", true)
                                put("deviceId", senderDeviceId)
                                put("protocolVersion", LocalCastProtocol.PROTOCOL_VERSION)
                            }
                            sendHttpResponse(output, 200, "OK", "application/json", successJson.toString().toByteArray())
                        } else {
                            val failJson = JSONObject().apply {
                                put("status", "error")
                                put("type", LocalCastProtocol.TYPE_PAIR_RESULT)
                                put("paired", false)
                                put("reason", if (!isSessionValid) "SESSION_EXPIRED" else "INVALID_PIN")
                            }
                            sendHttpResponse(output, 401, "Unauthorized", "application/json", failJson.toString().toByteArray())
                        }
                    }

                    (path == "/api/v1/pair/unpair" || path == "/pair/unpair") && method == "POST" -> {
                        val body = readRequestBodyAsString(input, requestHeaders)
                        val json = if (body.isNotEmpty()) JSONObject(body) else JSONObject()
                        val deviceId = json.optString("deviceId", "")
                        if (deviceId.isNotEmpty()) {
                            onDeviceUnpaired?.invoke(deviceId)
                        }
                        val okJson = JSONObject().apply {
                            put("status", "ok")
                            put("type", LocalCastProtocol.TYPE_UNPAIR)
                        }
                        sendHttpResponse(output, 200, "OK", "application/json", okJson.toString().toByteArray())
                    }

                    (path == "/api/v1/transfer/request" || path == "/transfer/request") && method == "POST" -> {
                        val body = readRequestBodyAsString(input, requestHeaders)
                        val json = if (body.isNotEmpty()) JSONObject(body) else JSONObject()
                        val transferId = json.optString("transferId", UUID.randomUUID().toString())
                        val fileSize = json.optLong("fileSize", 0L)

                        val targetDir = File(context.cacheDir, "received_transfers")
                        if (!targetDir.exists()) targetDir.mkdirs()
                        val partFile = File(targetDir, "$transferId.part")

                        val existingOffset = if (partFile.exists()) partFile.length() else 0L
                        val isResume = existingOffset > 0L && existingOffset < fileSize

                        val resp = JSONObject().apply {
                            put("status", "ok")
                            put("type", LocalCastProtocol.TYPE_TRANSFER_RESPONSE)
                            put("transferId", transferId)
                            put("action", if (isResume) "RESUME_REQUIRED" else "ACCEPTED")
                            put("offset", if (isResume) existingOffset else 0L)
                            put("supportsResume", true)
                        }
                        sendHttpResponse(output, 200, "OK", "application/json", resp.toString().toByteArray())
                    }

                    (path == "/api/v1/transfer/cancel" || path == "/transfer/cancel") && method == "POST" -> {
                        val body = readRequestBodyAsString(input, requestHeaders)
                        val json = if (body.isNotEmpty()) JSONObject(body) else JSONObject()
                        val transferId = json.optString("transferId", "")
                        val deletePart = json.optBoolean("deletePart", false)

                        if (deletePart && transferId.isNotEmpty()) {
                            val partFile = File(File(context.cacheDir, "received_transfers"), "$transferId.part")
                            if (partFile.exists()) partFile.delete()
                        }
                        val okJson = JSONObject().apply { put("status", "ok") }
                        sendHttpResponse(output, 200, "OK", "application/json", okJson.toString().toByteArray())
                    }

                    (path == "/api/v1/control" || path == "/control") && method == "POST" -> {
                        val body = readRequestBodyAsString(input, requestHeaders)
                        val json = if (body.isNotEmpty()) JSONObject(body) else JSONObject()
                        val rawCmd = json.optString("command", "PLAY")
                        val pos = json.optLong("positionMs", 0L)
                        val vol = json.optDouble("volume", 1.0).toFloat()

                        val cmd = try {
                            PlaybackControlCommand.valueOf(rawCmd.uppercase())
                        } catch (e: Exception) {
                            PlaybackControlCommand.PLAY
                        }

                        when (cmd) {
                            PlaybackControlCommand.PLAY -> activePlaybackState = ReceiverPlaybackState.PLAYING
                            PlaybackControlCommand.PAUSE -> activePlaybackState = ReceiverPlaybackState.PAUSED
                            PlaybackControlCommand.STOP -> activePlaybackState = ReceiverPlaybackState.STOPPED
                            PlaybackControlCommand.SEEK -> currentPositionMs = pos
                            PlaybackControlCommand.VOLUME -> currentVolume = vol
                        }

                        onPlaybackControl?.invoke(cmd, pos, vol)

                        val resp = JSONObject().apply {
                            put("status", "ok")
                            put("type", LocalCastProtocol.TYPE_RECEIVER_STATE)
                            put("receiverState", activePlaybackState.name)
                            put("positionMs", currentPositionMs)
                            put("volume", currentVolume.toDouble())
                        }
                        sendHttpResponse(output, 200, "OK", "application/json", resp.toString().toByteArray())
                    }

                    (path == "/api/v1/control/state" || path == "/control/state") && method == "GET" -> {
                        val resp = JSONObject().apply {
                            put("status", "ok")
                            put("type", LocalCastProtocol.TYPE_RECEIVER_STATE)
                            put("receiverState", activePlaybackState.name)
                            put("activeMediaId", activeCastingItem?.id ?: "")
                            put("activeTitle", activeCastingItem?.title ?: "")
                            put("activeMime", activeCastingItem?.mimeType ?: "")
                            put("positionMs", currentPositionMs)
                            put("volume", currentVolume.toDouble())
                        }
                        sendHttpResponse(output, 200, "OK", "application/json", resp.toString().toByteArray())
                    }

                    path.startsWith("/media/") -> {
                        val mediaId = path.removePrefix("/media/").substringBefore("?")
                        if (mediaId.contains("..") || mediaId.contains("/") || mediaId.contains("\\")) {
                            sendHttpResponse(output, 400, "Bad Request", "text/plain", "Invalid media identifier".toByteArray())
                        } else {
                            serveMediaContent(mediaId, requestHeaders, output)
                        }
                    }

                    path.startsWith("/api/v1/upload") && (method == "POST" || method == "PUT") -> {
                        handleFileUploadRequest(input, requestHeaders, output)
                    }

                    else -> {
                        val notFound = "<h1>404 Not Found</h1>"
                        sendHttpResponse(output, 404, "Not Found", "text/html", notFound.toByteArray())
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Client socket handler completed or interrupted: ${e.message}")
            }
        }
    }

    private fun readRequestBodyAsString(input: InputStream, headers: Map<String, String>): String {
        val contentLength = headers["content-length"]?.toIntOrNull() ?: 0
        if (contentLength <= 0) return ""
        val bytes = ByteArray(contentLength.coerceAtMost(65536))
        var readTotal = 0
        while (readTotal < bytes.size) {
            val r = input.read(bytes, readTotal, bytes.size - readTotal)
            if (r == -1) break
            readTotal += r
        }
        return String(bytes, 0, readTotal, Charsets.UTF_8)
    }

    private fun parseHttpRequestHeaders(input: InputStream): Map<String, String>? {
        val headerBuffer = java.io.ByteArrayOutputStream()
        var b: Int
        var lastFour = 0

        while (input.read().also { b = it } != -1) {
            headerBuffer.write(b)
            lastFour = (lastFour shl 8) or (b and 0xFF)
            if (lastFour == 0x0D0A0D0A) { // \r\n\r\n
                break
            }
            if (headerBuffer.size() > 65536) { // 64 KB header size limit
                Log.e(TAG, "HTTP headers exceeded 64KB limit")
                return null
            }
        }

        if (headerBuffer.size() == 0) return null

        val headerText = headerBuffer.toString("UTF-8")
        val lines = headerText.split("\r\n")
        if (lines.isEmpty()) return null

        val requestLine = lines[0]
        val parts = requestLine.split(" ")
        if (parts.size < 2) return null

        val headers = HashMap<String, String>()
        headers["METHOD"] = parts[0].uppercase()
        headers["PATH"] = parts[1]

        for (i in 1 until lines.size) {
            val line = lines[i]
            if (line.isEmpty()) break
            val colonIndex = line.indexOf(":")
            if (colonIndex > 0) {
                val headerName = line.substring(0, colonIndex).trim().lowercase()
                val headerValue = line.substring(colonIndex + 1).trim()
                headers[headerName] = headerValue
            }
        }
        return headers
    }

    private fun sanitizeFilename(rawName: String): String {
        var name = File(rawName).name // Strips parent directory paths
        name = name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        if (name.isEmpty() || name.startsWith(".")) {
            name = "received_file_${System.currentTimeMillis()}"
        }
        return name
    }

    private fun serveWebReceiverHtml(output: OutputStream) {
        val pinForReceiver = deviceIdentityRepository.getPairingPinForDisplay()
        val deviceName = deviceIdentityRepository.deviceName
        val activeMedia = activeCastingItem
        val activeMediaUrl = if (activeMedia != null) "/media/${activeMedia.id}" else ""
        val activeMediaMime = activeMedia?.mimeType ?: ""

        val html = """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>LocalCast Receiver - $deviceName</title>
                <style>
                    :root {
                        --bg: #0b1120;
                        --card: #1e293b;
                        --card-border: #334155;
                        --accent: #38bdf8;
                        --accent-hover: #0ea5e9;
                        --text: #f8fafc;
                        --text-muted: #94a3b8;
                        --success: #34d399;
                        --warn: #fbbf24;
                    }
                    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
                    body { background: var(--bg); color: var(--text); min-height: 100vh; display: flex; flex-direction: column; }
                    header { background: #0f172a; border-bottom: 1px solid var(--card-border); padding: 1.25rem 2rem; display: flex; align-items: center; justify-content: space-between; }
                    .brand { display: flex; align-items: center; gap: 0.75rem; }
                    .brand-icon { width: 32px; height: 32px; background: var(--accent); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #0f172a; font-weight: 900; font-size: 1.1rem; }
                    .brand-title { font-size: 1.25rem; font-weight: 700; color: var(--text); letter-spacing: -0.02em; }
                    .net-status { display: flex; align-items: center; gap: 0.5rem; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.2); padding: 0.35rem 0.85rem; border-radius: 20px; font-size: 0.85rem; color: var(--accent); }
                    .net-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--success); }
                    main { flex: 1; max-width: 1000px; margin: 0 auto; width: 100%; padding: 2rem 1.5rem; display: flex; flex-direction: column; gap: 1.5rem; }
                    .grid { display: grid; grid-template-columns: 1fr 340px; gap: 1.5rem; }
                    @media (max-width: 768px) { .grid { grid-template-columns: 1fr; } }
                    .card { background: var(--card); border: 1px solid var(--card-border); border-radius: 16px; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2); }
                    .card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; border-bottom: 1px solid var(--card-border); padding-bottom: 0.75rem; }
                    .card-title { font-size: 1.1rem; font-weight: 600; display: flex; align-items: center; gap: 0.5rem; }
                    .media-container { width: 100%; min-height: 340px; background: #000; border-radius: 12px; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden; }
                    video, audio, img { max-width: 100%; max-height: 480px; border-radius: 8px; }
                    .placeholder { text-align: center; color: var(--text-muted); padding: 2rem; }
                    .dropzone { border: 2px dashed var(--accent); border-radius: 12px; padding: 2rem 1.5rem; text-align: center; background: rgba(56, 189, 248, 0.04); cursor: pointer; transition: all 0.2s ease; }
                    .dropzone:hover { background: rgba(56, 189, 248, 0.08); border-color: var(--accent-hover); }
                    input[type="file"] { display: none; }
                    .pin-display { background: rgba(15, 23, 42, 0.8); border: 1px solid var(--card-border); border-radius: 12px; padding: 1.25rem; text-align: center; }
                    .pin-number { font-size: 2.2rem; font-weight: 800; letter-spacing: 0.35rem; color: var(--accent); margin: 0.5rem 0; font-family: monospace; }
                    .progress-bar-bg { width: 100%; height: 8px; background: #0f172a; border-radius: 4px; overflow: hidden; margin: 0.75rem 0; }
                    .progress-bar-fill { height: 100%; width: 0%; background: var(--accent); transition: width 0.2s ease; }
                    .btn { background: var(--accent); color: #0f172a; border: none; padding: 0.65rem 1.25rem; border-radius: 8px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 0.5rem; }
                    .btn:hover { background: var(--accent-hover); }
                    .controls-bar { display: flex; gap: 0.5rem; justify-content: center; margin-top: 1rem; }
                    .icon-btn { background: #0f172a; border: 1px solid var(--card-border); color: var(--text); padding: 0.5rem 1rem; border-radius: 8px; cursor: pointer; font-size: 0.9rem; }
                    .icon-btn:hover { background: var(--card-border); }
                </style>
            </head>
            <body>
                <header>
                    <div class="brand">
                        <div class="brand-icon">LC</div>
                        <div class="brand-title">LocalCast Receiver</div>
                    </div>
                    <div class="net-status">
                        <div class="net-dot"></div>
                        <span>Offline Local Network Ready</span>
                    </div>
                </header>

                <main>
                    <div class="grid">
                        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
                            <!-- Media Screen Card -->
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">📺 Media Display</div>
                                    <span id="media-status" style="font-size: 0.85rem; color: var(--text-muted);">Idle</span>
                                </div>
                                <div class="media-container" id="media-host">
                                    <div class="placeholder" id="placeholder-text">
                                        <p style="font-size: 1.1rem; margin-bottom: 0.5rem;">Ready to Cast</p>
                                        <p style="font-size: 0.9rem; color: var(--text-muted);">Send videos, photos, or audio from the LocalCast Android app</p>
                                    </div>
                                </div>
                                <div class="controls-bar" id="media-controls" style="display: none;">
                                    <button class="icon-btn" onclick="sendControl('PAUSE')">⏸ Pause</button>
                                    <button class="icon-btn" onclick="sendControl('PLAY')">▶ Play</button>
                                    <button class="icon-btn" onclick="sendControl('STOP')">⏹ Stop</button>
                                </div>
                            </div>

                            <!-- File Receiver Dropzone -->
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">📁 Send File to Phone / Device</div>
                                </div>
                                <div class="dropzone" id="drop-area" onclick="document.getElementById('file-input').click()">
                                    <p style="font-size: 1rem; font-weight: 600; margin-bottom: 0.25rem;">Drop files here or click to browse</p>
                                    <p style="font-size: 0.85rem; color: var(--text-muted);">Transfer documents, media, and folders locally over Wi-Fi</p>
                                    <input type="file" id="file-input" onchange="handleFileSelected(this.files[0])">
                                </div>
                                <div id="upload-progress-card" style="display: none; margin-top: 1rem;">
                                    <div style="display: flex; justify-content: space-between; font-size: 0.85rem;">
                                        <span id="upload-filename">File</span>
                                        <span id="upload-percent">0%</span>
                                    </div>
                                    <div class="progress-bar-bg">
                                        <div class="progress-bar-fill" id="upload-fill"></div>
                                    </div>
                                    <p id="upload-status-text" style="font-size: 0.85rem; color: var(--accent);"></p>
                                </div>
                            </div>
                        </div>

                        <!-- Sidebar / Pairing & Device Info -->
                        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">🔐 Temporary Pairing PIN</div>
                                </div>
                                <div class="pin-display">
                                    <p style="font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase;">Session Verification PIN</p>
                                    <div class="pin-number" id="pin-text">$pinForReceiver</div>
                                    <p style="font-size: 0.75rem; color: var(--text-muted);">Enter this 6-digit PIN on the sender device</p>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">ℹ️ Receiver Details</div>
                                </div>
                                <div style="font-size: 0.9rem; line-height: 1.6; color: var(--text-muted);">
                                    <p><strong style="color: var(--text);">Device:</strong> $deviceName</p>
                                    <p><strong style="color: var(--text);">Protocol:</strong> LocalCast v1.0</p>
                                    <p><strong style="color: var(--text);">Port:</strong> $port</p>
                                    <p><strong style="color: var(--text);">Security:</strong> Local-Only SHA-256</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>

                <script>
                    let activeMediaUrl = "$activeMediaUrl";
                    let activeMediaMime = "$activeMediaMime";

                    function checkReceiverState() {
                        fetch('/api/v1/control/state')
                            .then(r => r.json())
                            .then(data => {
                                if (data.activeMediaId && data.activeMediaId.length > 0) {
                                    const mediaUrl = '/media/' + data.activeMediaId;
                                    if (activeMediaUrl !== mediaUrl) {
                                        activeMediaUrl = mediaUrl;
                                        activeMediaMime = data.activeMime || '';
                                        renderMedia(mediaUrl, activeMediaMime, data.activeTitle);
                                    }
                                }
                            }).catch(() => {});
                    }

                    function renderMedia(url, mime, title) {
                        const host = document.getElementById('media-host');
                        const status = document.getElementById('media-status');
                        const controls = document.getElementById('media-controls');
                        status.innerText = title || 'Playing Media';
                        controls.style.display = 'flex';

                        if (mime.startsWith('video/')) {
                            host.innerHTML = '<video id="active-video" controls autoplay src="' + url + '"></video>';
                        } else if (mime.startsWith('audio/')) {
                            host.innerHTML = '<div style="padding: 2rem; text-align: center;"><audio id="active-audio" controls autoplay src="' + url + '"></audio><p style="margin-top: 1rem; color: var(--accent);">' + (title || 'Audio Stream') + '</p></div>';
                        } else if (mime.startsWith('image/')) {
                            host.innerHTML = '<img src="' + url + '" alt="' + (title || 'Photo') + '">';
                        } else {
                            host.innerHTML = '<p style="color: var(--accent);">' + (title || 'Media') + ' is active</p>';
                        }
                    }

                    function sendControl(cmd) {
                        fetch('/api/v1/control', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ command: cmd })
                        });
                    }

                    function handleFileSelected(file) {
                        if (!file) return;
                        const card = document.getElementById('upload-progress-card');
                        const nameLabel = document.getElementById('upload-filename');
                        const fill = document.getElementById('upload-fill');
                        const percent = document.getElementById('upload-percent');
                        const status = document.getElementById('upload-status-text');

                        card.style.display = 'block';
                        nameLabel.innerText = file.name;
                        fill.style.width = '0%';
                        percent.innerText = '0%';
                        status.innerText = 'Uploading to device...';

                        const xhr = new XMLHttpRequest();
                        xhr.open('POST', '/api/v1/upload?filename=' + encodeURIComponent(file.name), true);
                        xhr.setRequestHeader('Content-Type', 'application/octet-stream');
                        xhr.setRequestHeader('X-Total-Size', file.size);

                        xhr.upload.onprogress = function(e) {
                            if (e.lengthComputable) {
                                const p = Math.round((e.loaded / e.total) * 100);
                                fill.style.width = p + '%';
                                percent.innerText = p + '%';
                            }
                        };

                        xhr.onload = function() {
                            if (xhr.status >= 200 && xhr.status < 300) {
                                fill.style.width = '100%';
                                percent.innerText = '100%';
                                status.innerText = '✓ Transfer verified and complete';
                            } else {
                                status.innerText = '❌ Error ' + xhr.status + ': Transfer failed';
                            }
                        };

                        xhr.onerror = function() {
                            status.innerText = '❌ Connection lost during transfer';
                        };

                        xhr.send(file);
                    }

                    setInterval(checkReceiverState, 3000);
                </script>
            </body>
            </html>
        """.trimIndent()
        sendHttpResponse(output, 200, "OK", "text/html; charset=UTF-8", html.toByteArray())
    }

    private fun getMediaTotalLength(media: MediaResource): Long {
        if (media.file != null && media.file.exists()) return media.file.length()
        if (media.contentLength > 0) return media.contentLength
        if (media.uri != null) {
            try {
                context.contentResolver.openFileDescriptor(media.uri, "r")?.use { pfd ->
                    return pfd.statSize
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to query statSize for URI: ${media.uri}")
            }
        }
        return 0L
    }

    private fun skipFully(inputStream: InputStream, bytesToSkip: Long): Boolean {
        var remaining = bytesToSkip
        val buffer = ByteArray(16384)
        while (remaining > 0) {
            val skipped = inputStream.skip(remaining)
            if (skipped > 0) {
                remaining -= skipped
            } else {
                val read = inputStream.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                if (read == -1) return false
                remaining -= read
            }
        }
        return true
    }

    private fun serveMediaContent(mediaId: String, headers: Map<String, String>, output: OutputStream) {
        val media = registeredMediaMap[mediaId]
        if (media == null) {
            sendHttpResponse(output, 404, "Not Found", "text/html", "Media not registered".toByteArray())
            return
        }

        try {
            val totalLength = getMediaTotalLength(media)
            val inputStream: InputStream = when {
                media.file != null && media.file.exists() -> FileInputStream(media.file)
                media.uri != null -> context.contentResolver.openInputStream(media.uri) ?: return
                else -> return
            }

            val rangeHeader = headers["range"]
            if (rangeHeader != null && rangeHeader.startsWith("bytes=")) {
                val rangeValue = rangeHeader.removePrefix("bytes=").trim()
                var start = 0L
                var end = if (totalLength > 0) totalLength - 1 else Long.MAX_VALUE

                if (rangeValue.startsWith("-")) {
                    val suffix = rangeValue.removePrefix("-").toLongOrNull() ?: 0L
                    if (totalLength > 0) {
                        start = (totalLength - suffix).coerceAtLeast(0L)
                        end = totalLength - 1
                    }
                } else {
                    val parts = rangeValue.split("-")
                    start = parts[0].toLongOrNull() ?: 0L
                    if (parts.size > 1 && parts[1].isNotEmpty()) {
                        end = parts[1].toLongOrNull() ?: end
                    }
                }

                if (totalLength > 0 && (start < 0 || start >= totalLength || start > end)) {
                    val errorHeader = "HTTP/1.1 416 Range Not Satisfiable\r\n" +
                            "Content-Range: bytes */$totalLength\r\n" +
                            "Content-Length: 0\r\n" +
                            "Access-Control-Allow-Origin: *\r\n" +
                            "Connection: close\r\n\r\n"
                    output.write(errorHeader.toByteArray(Charsets.UTF_8))
                    output.flush()
                    inputStream.close()
                    return
                }

                if (totalLength > 0) {
                    end = end.coerceAtMost(totalLength - 1)
                }
                val contentLength = if (totalLength > 0) (end - start + 1).coerceAtLeast(0L) else Long.MAX_VALUE

                if (!skipFully(inputStream, start)) {
                    sendHttpResponse(output, 416, "Range Not Satisfiable", "text/plain", "Seek failed".toByteArray())
                    inputStream.close()
                    return
                }

                val contentRangeHeader = if (totalLength > 0) "bytes $start-$end/$totalLength" else "bytes $start-$end/*"
                val headerStr = "HTTP/1.1 206 Partial Content\r\n" +
                        "Content-Type: ${media.mimeType}\r\n" +
                        "Accept-Ranges: bytes\r\n" +
                        "Content-Range: $contentRangeHeader\r\n" +
                        (if (totalLength > 0) "Content-Length: $contentLength\r\n" else "") +
                        "Access-Control-Allow-Origin: *\r\n" +
                        "Connection: close\r\n\r\n"
                output.write(headerStr.toByteArray(Charsets.UTF_8))

                streamBytes(inputStream, output, contentLength)
            } else {
                val headerStr = "HTTP/1.1 200 OK\r\n" +
                        "Content-Type: ${media.mimeType}\r\n" +
                        "Accept-Ranges: bytes\r\n" +
                        (if (totalLength > 0) "Content-Length: $totalLength\r\n" else "") +
                        "Access-Control-Allow-Origin: *\r\n" +
                        "Connection: close\r\n\r\n"
                output.write(headerStr.toByteArray(Charsets.UTF_8))

                streamBytes(inputStream, output, if (totalLength > 0) totalLength else Long.MAX_VALUE)
            }
            inputStream.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error serving media content: ${e.message}")
        }
    }

    private fun handleFileUploadRequest(input: InputStream, headers: Map<String, String>, output: OutputStream) {
        try {
            val path = headers["PATH"] ?: ""
            var rawFileName = "received_file_${System.currentTimeMillis()}"
            if (path.contains("filename=")) {
                val encodedName = path.substringAfter("filename=").substringBefore("&")
                rawFileName = URLDecoder.decode(encodedName, "UTF-8")
            }

            val safeFileName = sanitizeFilename(rawFileName)
            val transferId = headers["x-transfer-id"] ?: UUID.randomUUID().toString()
            val expectedChecksum = headers["x-expected-checksum"]

            val rangeHeader = headers["content-range"] ?: headers["range"]
            var resumeOffset = 0L
            if (rangeHeader != null && rangeHeader.startsWith("bytes")) {
                val rangePart = rangeHeader.substringAfter("bytes").trim().substringBefore("/").trim()
                resumeOffset = rangePart.substringBefore("-").toLongOrNull() ?: 0L
            } else {
                resumeOffset = headers["x-resume-offset"]?.toLongOrNull() ?: 0L
            }

            val totalSize = headers["x-total-size"]?.toLongOrNull()
                ?: headers["content-length"]?.toLongOrNull()
                ?: -1L

            val targetDir = File(context.cacheDir, "received_transfers")
            if (!targetDir.exists()) targetDir.mkdirs()

            val partFile = File(targetDir, "$transferId.part")
            val existingLength = if (partFile.exists()) partFile.length() else 0L

            // Strict Resume Offset Validation:
            if (resumeOffset == 0L) {
                // New or reset transfer: remove any stale .part file to avoid corrupt append
                if (partFile.exists()) {
                    partFile.delete()
                }
            } else {
                // Resumed transfer: must have existing part file and exact matching length
                if (!partFile.exists() || existingLength != resumeOffset) {
                    Log.w(TAG, "Resume offset mismatch for transfer $transferId: expected $existingLength, provided $resumeOffset")
                    val mismatchJson = JSONObject().apply {
                        put("status", "error")
                        put("error", "RESUME_OFFSET_MISMATCH")
                        put("expectedOffset", existingLength)
                        put("providedOffset", resumeOffset)
                    }
                    sendHttpResponse(output, 409, "Conflict", "application/json", mismatchJson.toString().toByteArray())
                    return
                }
            }

            val isAppend = resumeOffset > 0 && partFile.exists()
            val fileOut = FileOutputStream(partFile, isAppend)

            val buffer = ByteArray(32768)
            var bytesRead: Int

            val contentLengthHeader = headers["content-length"]?.toLongOrNull() ?: -1L
            if (contentLengthHeader > 0) {
                var remaining = contentLengthHeader
                while (remaining > 0) {
                    val toRead = buffer.size.coerceAtMost(remaining.toInt())
                    bytesRead = input.read(buffer, 0, toRead)
                    if (bytesRead <= 0) break
                    fileOut.write(buffer, 0, bytesRead)
                    remaining -= bytesRead
                }
            } else {
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    fileOut.write(buffer, 0, bytesRead)
                }
            }
            fileOut.flush()
            fileOut.close()

            val finalLength = partFile.length()
            val isComplete = (totalSize <= 0L) || (finalLength >= totalSize)

            if (isComplete) {
                // Compute SHA-256 over the complete assembled file
                val calculatedChecksum = ChecksumUtil.calculateSha256(partFile)

                if (!expectedChecksum.isNullOrBlank() && !expectedChecksum.equals(calculatedChecksum, ignoreCase = true)) {
                    Log.e(TAG, "Checksum verification failed for $transferId! Expected: $expectedChecksum, Actual: $calculatedChecksum")
                    val errorJson = JSONObject().apply {
                        put("status", "error")
                        put("error", "CHECKSUM_MISMATCH")
                        put("expectedChecksum", expectedChecksum)
                        put("actualChecksum", calculatedChecksum)
                    }
                    sendHttpResponse(output, 400, "Bad Request", "application/json", errorJson.toString().toByteArray())
                    return
                }

                // Move verified .part file to final destination
                val finalDestination = File(targetDir, safeFileName)
                if (finalDestination.exists()) finalDestination.delete()
                partFile.renameTo(finalDestination)

                val item = TransferItem(
                    id = transferId,
                    fileName = safeFileName,
                    fileSize = finalDestination.length(),
                    mimeType = "application/octet-stream",
                    uriString = Uri.fromFile(finalDestination).toString(),
                    direction = TransferDirection.RECEIVE,
                    bytesTransferred = finalDestination.length(),
                    status = TransferStatus.COMPLETED,
                    targetDeviceName = "Local Client",
                    targetDeviceIp = "Local Network",
                    timestamp = System.currentTimeMillis(),
                    checksum = calculatedChecksum
                )

                onFileReceived?.invoke(item)

                val successJson = JSONObject().apply {
                    put("status", "ok")
                    put("transferId", transferId)
                    put("file", safeFileName)
                    put("size", finalDestination.length())
                    put("checksum", calculatedChecksum)
                }
                sendHttpResponse(output, 200, "OK", "application/json", successJson.toString().toByteArray())
            } else {
                // Partial transfer chunk recorded
                val partialJson = JSONObject().apply {
                    put("status", "ok")
                    put("transferId", transferId)
                    put("received", finalLength)
                    put("total", totalSize)
                }
                sendHttpResponse(output, 206, "Partial Content", "application/json", partialJson.toString().toByteArray())
            }
        } catch (e: Exception) {
            Log.e(TAG, "File upload error", e)
            val errorJson = JSONObject().apply {
                put("status", "error")
                put("error", e.message ?: "Internal upload error")
            }
            sendHttpResponse(output, 500, "Internal Error", "application/json", errorJson.toString().toByteArray())
        }
    }

    private fun sendCorsOptionsResponse(output: OutputStream) {
        val header = "HTTP/1.1 204 No Content\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Range, Authorization, X-Transfer-Id, X-Total-Size, X-Resume-Offset, X-Expected-Checksum\r\n" +
                "Access-Control-Max-Age: 86400\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun streamBytes(input: InputStream, output: OutputStream, maxBytes: Long) {
        val buffer = ByteArray(32768)
        var remaining = maxBytes
        while (remaining > 0) {
            val toRead = buffer.size.coerceAtMost(remaining.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            val readLen = input.read(buffer, 0, toRead)
            if (readLen <= 0) break
            output.write(buffer, 0, readLen)
            remaining -= readLen
        }
        output.flush()
    }

    private fun sendHttpResponse(
        output: OutputStream,
        statusCode: Int,
        statusText: String,
        contentType: String,
        body: ByteArray
    ) {
        val header = "HTTP/1.1 $statusCode $statusText\r\n" +
                "Content-Type: $contentType\r\n" +
                "Content-Length: ${body.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Connection: close\r\n" +
                "\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(body)
        output.flush()
    }
}
