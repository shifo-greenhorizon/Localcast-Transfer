package com.localcast.transfer.network.protocol

import android.content.Context
import android.net.Uri
import android.util.Log
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.PlaybackControlCommand
import com.localcast.transfer.model.ReceiverPlaybackState
import com.localcast.transfer.model.TransferItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class SendResult(
    val success: Boolean,
    val bytesSent: Long,
    val checksum: String? = null,
    val errorMessage: String? = null
)

data class PairChallengeResult(
    val success: Boolean,
    val sessionId: String = "",
    val requiresPin: Boolean = true,
    val expiresInMs: Long = 60000L,
    val errorMessage: String? = null
)

data class PairVerifyResult(
    val success: Boolean,
    val isPaired: Boolean = false,
    val deviceId: String = "",
    val errorMessage: String? = null
)

data class TransferNegotiationResult(
    val accepted: Boolean,
    val resumeOffset: Long = 0L,
    val requiresResume: Boolean = false,
    val errorMessage: String? = null
)

data class ReceiverStateResult(
    val state: ReceiverPlaybackState,
    val activeMediaId: String? = null,
    val activeTitle: String? = null,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val volume: Float = 1.0f
)

class LocalCastClient(private val context: Context) {

    private val TAG = "LocalCast/Client"

    suspend fun fetchDeviceInfo(ip: String, port: Int): Device? = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://$ip:$port/api/v1/device")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3000
                readTimeout = 3000
            }
            if (conn.responseCode in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(body)
                LocalCastProtocol.parseDeviceInfo(json, fallbackIp = ip, fallbackPort = port)
            } else {
                conn.disconnect()
                null
            }
        } catch (e: Exception) {
            Log.d(TAG, "Could not fetch device info from $ip:$port: ${e.message}")
            null
        }
    }

    suspend fun requestPairing(
        device: Device,
        senderDeviceId: String,
        senderName: String
    ): PairChallengeResult = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://${device.ipAddress}:${device.port}/api/v1/pair/request")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("Content-Type", "application/json")
            }

            val payload = LocalCastProtocol.createPairRequestJson(senderDeviceId, senderName)
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val responseCode = conn.responseCode
            val responseStream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
            val responseText = responseStream?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()

            if (responseCode in 200..299 && responseText.isNotEmpty()) {
                val json = JSONObject(responseText)
                PairChallengeResult(
                    success = true,
                    sessionId = json.optString("sessionId", ""),
                    requiresPin = json.optBoolean("requiresPin", true),
                    expiresInMs = json.optLong("expiresInMs", 60000L)
                )
            } else {
                PairChallengeResult(
                    success = false,
                    errorMessage = "Pair request rejected with HTTP $responseCode: $responseText"
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initiating pairing request to ${device.deviceName}", e)
            PairChallengeResult(success = false, errorMessage = e.message ?: "Connection error")
        }
    }

    suspend fun verifyPairingPin(
        device: Device,
        sessionId: String,
        pin: String,
        senderDeviceId: String,
        senderName: String
    ): PairVerifyResult = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://${device.ipAddress}:${device.port}/api/v1/pair/verify")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("Content-Type", "application/json")
            }

            val payload = LocalCastProtocol.createPairVerifyJson(sessionId, pin, senderDeviceId, senderName)
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val responseCode = conn.responseCode
            val responseStream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
            val responseText = responseStream?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()

            if (responseCode in 200..299 && responseText.isNotEmpty()) {
                val json = JSONObject(responseText)
                val paired = json.optBoolean("paired", false)
                PairVerifyResult(
                    success = paired,
                    isPaired = paired,
                    deviceId = json.optString("deviceId", device.deviceId),
                    errorMessage = if (!paired) json.optString("reason", "Verification failed") else null
                )
            } else {
                PairVerifyResult(
                    success = false,
                    errorMessage = "Invalid PIN or pairing expired (HTTP $responseCode)"
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error verifying PIN with ${device.deviceName}", e)
            PairVerifyResult(success = false, errorMessage = e.message ?: "Verification error")
        }
    }

    suspend fun unpairDevice(device: Device, senderDeviceId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://${device.ipAddress}:${device.port}/api/v1/pair/unpair")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("Content-Type", "application/json")
            }

            val payload = JSONObject().apply {
                put("type", LocalCastProtocol.TYPE_UNPAIR)
                put("deviceId", senderDeviceId)
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        } catch (e: Exception) {
            Log.w(TAG, "Unpair notification to ${device.deviceName} failed: ${e.message}")
            false
        }
    }

    suspend fun negotiateTransfer(
        device: Device,
        transferItem: TransferItem
    ): TransferNegotiationResult = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://${device.ipAddress}:${device.port}/api/v1/transfer/request")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("Content-Type", "application/json")
            }

            val payload = LocalCastProtocol.createTransferRequestJson(
                transferId = transferItem.id,
                fileName = transferItem.fileName,
                fileSize = transferItem.fileSize,
                mimeType = transferItem.mimeType,
                checksum = transferItem.checksum,
                supportsResume = true
            )
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val responseCode = conn.responseCode
            val responseStream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
            val responseText = responseStream?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()

            if (responseCode in 200..299 && responseText.isNotEmpty()) {
                val json = JSONObject(responseText)
                val action = json.optString("action", "ACCEPTED")
                val offset = json.optLong("offset", 0L)
                TransferNegotiationResult(
                    accepted = true,
                    resumeOffset = offset,
                    requiresResume = action == "RESUME_REQUIRED" && offset > 0L
                )
            } else {
                TransferNegotiationResult(
                    accepted = false,
                    errorMessage = "Transfer rejected by receiver (HTTP $responseCode)"
                )
            }
        } catch (e: Exception) {
            Log.d(TAG, "Negotiation failed or endpoint not implemented, proceeding with standard transfer: ${e.message}")
            // Graceful fallback for standard transfers
            TransferNegotiationResult(accepted = true, resumeOffset = 0L)
        }
    }

    suspend fun sendControlCommand(
        device: Device,
        command: PlaybackControlCommand,
        positionMs: Long = 0L,
        volume: Float = 1.0f
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://${device.ipAddress}:${device.port}/api/v1/control")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("Content-Type", "application/json")
            }

            val payload = LocalCastProtocol.createControlCommandJson(command, positionMs, volume)
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send control command $command to ${device.deviceName}", e)
            false
        }
    }

    suspend fun fetchReceiverState(device: Device): ReceiverStateResult? = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://${device.ipAddress}:${device.port}/api/v1/control/state")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3000
                readTimeout = 3000
            }
            if (conn.responseCode in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(body)
                val rawState = json.optString("receiverState", "IDLE")
                val state = try {
                    ReceiverPlaybackState.valueOf(rawState.uppercase())
                } catch (e: Exception) {
                    ReceiverPlaybackState.IDLE
                }
                ReceiverStateResult(
                    state = state,
                    activeMediaId = json.optString("activeMediaId", null),
                    activeTitle = json.optString("activeTitle", null),
                    positionMs = json.optLong("positionMs", 0L),
                    durationMs = json.optLong("durationMs", 0L),
                    volume = json.optDouble("volume", 1.0).toFloat()
                )
            } else {
                conn.disconnect()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun sendFileToDevice(
        device: Device,
        transferItem: TransferItem,
        resumeOffset: Long = 0L,
        onProgress: (bytesSent: Long, speedBps: Long, etaSec: Long) -> Unit
    ): SendResult = withContext(Dispatchers.IO) {
        try {
            val encodedName = URLEncoder.encode(transferItem.fileName, "UTF-8")
            val targetUrl = "http://${device.ipAddress}:${device.port}/api/v1/upload?filename=$encodedName"

            val url = URL(targetUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.connectTimeout = 8000
            connection.readTimeout = 60000
            connection.setRequestProperty("Content-Type", "application/octet-stream")
            connection.setRequestProperty("X-Transfer-Id", transferItem.id)
            connection.setRequestProperty("X-Total-Size", transferItem.fileSize.toString())

            val totalSize = transferItem.fileSize.coerceAtLeast(1L)
            if (resumeOffset > 0) {
                connection.setRequestProperty("Content-Range", "bytes $resumeOffset-${totalSize - 1}/$totalSize")
                connection.setRequestProperty("X-Resume-Offset", resumeOffset.toString())
            }

            val inputStream: InputStream? = when {
                transferItem.uriString.startsWith("file://") -> {
                    val path = Uri.parse(transferItem.uriString).path
                    if (path != null) File(path).inputStream() else null
                }
                transferItem.uriString.isNotEmpty() -> {
                    context.contentResolver.openInputStream(Uri.parse(transferItem.uriString))
                }
                else -> null
            }

            if (inputStream == null) {
                Log.e(TAG, "Cannot open input stream for file: ${transferItem.uriString}")
                return@withContext SendResult(
                    success = false,
                    bytesSent = resumeOffset,
                    errorMessage = "Cannot access local file source"
                )
            }

            val expectedChecksum = transferItem.checksum
            if (!expectedChecksum.isNullOrBlank()) {
                connection.setRequestProperty("X-Expected-Checksum", expectedChecksum)
            }

            if (resumeOffset > 0) {
                if (!skipFully(inputStream, resumeOffset)) {
                    inputStream.close()
                    return@withContext SendResult(
                        success = false,
                        bytesSent = 0L,
                        errorMessage = "Failed to seek file for resume"
                    )
                }
            }

            val remainingBytes = (totalSize - resumeOffset).coerceAtLeast(0L)
            if (remainingBytes <= Int.MAX_VALUE) {
                connection.setFixedLengthStreamingMode(remainingBytes)
            } else {
                connection.setChunkedStreamingMode(32768)
            }

            val outputStream: OutputStream = connection.outputStream
            val buffer = ByteArray(32768)
            var bytesRead: Int
            var totalSent = resumeOffset
            val startTime = System.currentTimeMillis()
            var lastReportTime = startTime

            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
                totalSent += bytesRead

                val now = System.currentTimeMillis()
                if (now - lastReportTime >= 200) {
                    val elapsedSec = (now - startTime) / 1000.0
                    val currentTransferred = totalSent - resumeOffset
                    val speedBps = if (elapsedSec > 0) (currentTransferred / elapsedSec).toLong() else 0L
                    val remaining = totalSize - totalSent
                    val etaSec = if (speedBps > 0) remaining / speedBps else 0L

                    onProgress(totalSent, speedBps, etaSec)
                    lastReportTime = now
                }
            }

            outputStream.flush()
            outputStream.close()
            inputStream.close()

            val responseCode = connection.responseCode
            var responseChecksum: String? = null
            var serverErrorMessage: String? = null

            val responseStream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
            if (responseStream != null) {
                try {
                    val responseBytes = responseStream.readBytes()
                    val jsonStr = String(responseBytes, Charsets.UTF_8)
                    val json = JSONObject(jsonStr)
                    if (json.has("checksum")) {
                        responseChecksum = json.getString("checksum")
                    }
                    if (json.has("error")) {
                        serverErrorMessage = json.getString("error")
                    } else if (json.has("message")) {
                        serverErrorMessage = json.getString("message")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Could not parse server JSON response: ${e.message}")
                }
            }

            connection.disconnect()

            if (responseCode in 200..299) {
                // If expectedChecksum is present, verify against response checksum
                if (!expectedChecksum.isNullOrBlank() && !responseChecksum.isNullOrBlank()) {
                    if (!expectedChecksum.equals(responseChecksum, ignoreCase = true)) {
                        Log.e(TAG, "Checksum mismatch! Expected: $expectedChecksum, Received: $responseChecksum")
                        return@withContext SendResult(
                            success = false,
                            bytesSent = totalSent,
                            checksum = responseChecksum,
                            errorMessage = "CHECKSUM_MISMATCH"
                        )
                    }
                }

                Log.i(TAG, "File transfer completed to ${device.deviceName}. Checksum: $responseChecksum")
                return@withContext SendResult(
                    success = true,
                    bytesSent = totalSent,
                    checksum = responseChecksum ?: expectedChecksum
                )
            } else {
                val error = serverErrorMessage ?: "Server returned HTTP $responseCode"
                Log.w(TAG, "Transfer failed with HTTP $responseCode: $error")
                return@withContext SendResult(
                    success = false,
                    bytesSent = if (responseCode == 409) 0L else totalSent,
                    errorMessage = error
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error sending file to device: ${device.deviceName}", e)
            return@withContext SendResult(
                success = false,
                bytesSent = resumeOffset,
                errorMessage = e.message ?: "Connection lost or timed out"
            )
        }
    }

    private fun skipFully(inputStream: InputStream, bytesToSkip: Long): Boolean {
        var remaining = bytesToSkip
        val buffer = ByteArray(16384)
        while (remaining > 0) {
            val skipped = inputStream.skip(remaining)
            if (skipped > 0) {
                remaining -= skipped
            } else {
                val read = inputStream.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                if (read == -1) return false
                remaining -= read
            }
        }
        return true
    }
}

