package com.localcast.transfer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localcast.transfer.model.PlaybackControlCommand
import com.localcast.transfer.ui.MainUiState
import com.localcast.transfer.ui.theme.BentoAccentLavender
import com.localcast.transfer.ui.theme.BentoCardBg
import com.localcast.transfer.ui.theme.BentoCardBorder
import com.localcast.transfer.ui.theme.BentoDarkPurple
import com.localcast.transfer.ui.theme.RoseError
import com.localcast.transfer.ui.theme.TextMuted
import com.localcast.transfer.ui.theme.TextPrimary

@Composable
fun CastScreen(
    state: MainUiState,
    onPickMediaClick: () -> Unit,
    onControlCommand: (PlaybackControlCommand, Long, Float) -> Unit,
    onStopCastClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val castingSession = state.castingSession

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("cast_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Media Casting & Streaming",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Stream local videos or photos to Smart TV or browser",
                fontSize = 13.sp,
                color = TextMuted
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = BentoCardBg),
                border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(BentoAccentLavender),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Cast,
                                    contentDescription = "Cast",
                                    tint = BentoDarkPurple
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (castingSession.isCasting) "Casting Active" else "No Active Stream",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = if (castingSession.isCasting) castingSession.targetDevice?.deviceName ?: "Web Receiver" else "Ready to cast",
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        if (castingSession.isCasting) {
                            IconButton(
                                onClick = onStopCastClick,
                                modifier = Modifier.testTag("stop_cast_button")
                            ) {
                                Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop", tint = RoseError)
                            }
                        }
                    }

                    if (castingSession.isCasting && castingSession.currentItem != null) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0D0E12))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = castingSession.currentItem.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = BentoAccentLavender
                                )
                                Text(
                                    text = castingSession.streamUrl,
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Remote Controls",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { onControlCommand(PlaybackControlCommand.SEEK, (castingSession.currentPositionMs - 10000).coerceAtLeast(0L), castingSession.volume) },
                                modifier = Modifier.testTag("rewind_button")
                            ) {
                                Icon(imageVector = Icons.Default.FastRewind, contentDescription = "Rewind 10s", tint = BentoAccentLavender)
                            }

                            Button(
                                onClick = {
                                    val nextCmd = if (castingSession.isPlaying) PlaybackControlCommand.PAUSE else PlaybackControlCommand.PLAY
                                    onControlCommand(nextCmd, castingSession.currentPositionMs, castingSession.volume)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BentoAccentLavender),
                                shape = CircleShape,
                                modifier = Modifier.testTag("play_pause_button")
                            ) {
                                Icon(
                                    imageVector = if (castingSession.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (castingSession.isPlaying) "Pause" else "Play",
                                    tint = BentoDarkPurple
                                )
                            }

                            IconButton(
                                onClick = { onControlCommand(PlaybackControlCommand.SEEK, castingSession.currentPositionMs + 10000, castingSession.volume) },
                                modifier = Modifier.testTag("fast_forward_button")
                            ) {
                                Icon(imageVector = Icons.Default.FastForward, contentDescription = "Forward 10s", tint = BentoAccentLavender)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.VolumeUp, contentDescription = "Volume", tint = TextMuted, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Slider(
                                value = castingSession.volume,
                                onValueChange = { newVol ->
                                    onControlCommand(PlaybackControlCommand.VOLUME, castingSession.currentPositionMs, newVol)
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = BentoAccentLavender,
                                    activeTrackColor = BentoAccentLavender,
                                    inactiveTrackColor = BentoCardBorder
                                ),
                                modifier = Modifier.weight(1f).testTag("volume_slider")
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onPickMediaClick,
                            colors = ButtonDefaults.buttonColors(containerColor = BentoAccentLavender),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("select_media_to_cast_button")
                        ) {
                            Icon(imageVector = Icons.Default.Movie, contentDescription = "Select Media", tint = BentoDarkPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Select Video / Photo to Cast", color = BentoDarkPurple, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = BentoCardBg),
                border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Web Receiver Player",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Any TV or computer on your Wi-Fi can open the URL below to stream directly:",
                        fontSize = 12.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0D0E12))
                            .border(1.dp, BentoCardBorder, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = state.webReceiverUrl,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = BentoAccentLavender
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

