package com.localcast.transfer.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid Design Theme Colors
val BentoDarkBg = Color(0xFF111318)
val BentoCardBg = Color(0xFF1C1B1F)
val BentoCardBorder = Color(0xFF49454F)

val BentoAccentLavender = Color(0xFFD0BCFF)
val BentoLavenderLight = Color(0xFFEADDFF)
val BentoDarkPurple = Color(0xFF381E72)
val BentoDeepPurple = Color(0xFF21005D)

val BentoMintGreen = Color(0xFFB4FF98)
val EmeraldSuccess = Color(0xFF10B981)
val RoseError = Color(0xFFF43F5E)

val TextPrimary = Color(0xFFE2E2E6)
val TextSecondary = Color(0xFFCAC4D0)
val TextMuted = Color(0xFF8E8A99)

// Compatibility aliases
val SlateDarkBg = BentoDarkBg
val SlateCardBg = BentoCardBg
val SlateCardBorder = BentoCardBorder
val CyanPrimary = BentoAccentLavender
val CyanPrimaryVariant = BentoLavenderLight
val VioletAccent = BentoAccentLavender
