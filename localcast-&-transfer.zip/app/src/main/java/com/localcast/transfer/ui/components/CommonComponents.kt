package com.localcast.transfer.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Phonelink
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.DeviceType
import com.localcast.transfer.model.NetworkStatus
import com.localcast.transfer.model.TransferItem
import com.localcast.transfer.model.TransferStatus
import com.localcast.transfer.ui.theme.BentoAccentLavender
import com.localcast.transfer.ui.theme.BentoCardBg
import com.localcast.transfer.ui.theme.BentoCardBorder
import com.localcast.transfer.ui.theme.BentoDarkBg
import com.localcast.transfer.ui.theme.BentoDarkPurple
import com.localcast.transfer.ui.theme.BentoDeepPurple
import com.localcast.transfer.ui.theme.BentoLavenderLight
import com.localcast.transfer.ui.theme.BentoMintGreen
import com.localcast.transfer.ui.theme.EmeraldSuccess
import com.localcast.transfer.ui.theme.RoseError
import com.localcast.transfer.ui.theme.TextMuted
import com.localcast.transfer.ui.theme.TextPrimary
import com.localcast.transfer.ui.theme.TextSecondary

@Composable
fun NetworkStatusCard(
    networkStatus: NetworkStatus,
    webReceiverUrl: String,
    onOpenReceiverClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("network_status_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = BentoCardBg),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (networkStatus.isLocalNetworkReady) BentoMintGreen else RoseError)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (networkStatus.isLocalNetworkReady) "LOCAL NETWORK READY" else "OFFLINE MODE",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BentoMintGreen,
                        letterSpacing = 1.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(BentoCardBorder.copy(alpha = 0.5f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (networkStatus.isWifiConnected) "Wi-Fi" else if (networkStatus.isHotspotActive) "Hotspot" else "Offline",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BentoAccentLavender),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = "Wi-Fi",
                        tint = BentoDarkPurple,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "CURRENT NETWORK",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoAccentLavender,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "${networkStatus.ssid} (${networkStatus.ipAddress})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF0D0E12))
                    .border(1.dp, BentoCardBorder, RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "WEB RECEIVER LINK",
                            fontSize = 10.sp,
                            color = TextMuted,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = webReceiverUrl,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = BentoAccentLavender
                        )
                    }

                    Button(
                        onClick = onOpenReceiverClick,
                        colors = ButtonDefaults.buttonColors(containerColor = BentoAccentLavender),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("open_web_receiver_button")
                    ) {
                        Text("Web Player", color = BentoDarkPurple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun LargeSendFilesBentoCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .testTag("bento_large_send_files"),
        colors = CardDefaults.cardColors(containerColor = BentoAccentLavender)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(BentoDarkPurple),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = "Send",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(BentoDarkPurple.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "P2P FAST",
                        color = BentoDarkPurple,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Send Files",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = BentoDarkPurple
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Any format, any size, zero cloud.",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = BentoDarkPurple.copy(alpha = 0.75f)
            )
        }
    }
}

@Composable
fun SmallBentoCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .testTag("bento_small_${title.lowercase().replace(" ", "_")}"),
        colors = CardDefaults.cardColors(containerColor = BentoCardBg),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(BentoCardBorder),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
        }
    }
}

@Composable
fun WideBentoCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .testTag("bento_wide_${title.lowercase().replace(" ", "_")}"),
        colors = CardDefaults.cardColors(containerColor = BentoCardBg),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(BentoLavenderLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = BentoDeepPurple,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .border(1.dp, BentoCardBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Arrow",
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun DeviceItemRow(
    device: Device,
    onConnectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("device_item_${device.deviceId}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1A21)),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val icon = when (device.deviceType) {
                    DeviceType.SMART_TV -> Icons.Default.Tv
                    DeviceType.COMPUTER -> Icons.Default.Computer
                    DeviceType.PHONE -> Icons.Default.PhoneAndroid
                    DeviceType.TABLET -> Icons.Default.Phonelink
                    else -> Icons.Default.Tv
                }

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BentoCardBorder),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = device.deviceName, tint = BentoAccentLavender)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = device.deviceName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "${device.ipAddress}:${device.port}",
                        fontSize = 11.sp,
                        color = BentoMintGreen
                    )
                }
            }

            Button(
                onClick = onConnectClick,
                colors = ButtonDefaults.buttonColors(containerColor = BentoAccentLavender),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Select", color = BentoDarkPurple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun TransferItemCard(
    transfer: TransferItem,
    onPauseClick: () -> Unit = {},
    onResumeClick: () -> Unit = {},
    onCancelClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = BentoCardBg),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = "File",
                        tint = BentoAccentLavender,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = transfer.fileName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "${formatBytes(transfer.bytesTransferred)} / ${formatBytes(transfer.fileSize)} • ${transfer.targetDeviceName}",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    val statusColor = when (transfer.status) {
                        TransferStatus.COMPLETED -> BentoMintGreen
                        TransferStatus.TRANSFERRING -> BentoAccentLavender
                        TransferStatus.PAUSED -> BentoAccentLavender.copy(alpha = 0.7f)
                        TransferStatus.FAILED -> RoseError
                        else -> TextMuted
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(statusColor.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = transfer.status.name,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        )
                    }

                    if (transfer.status == TransferStatus.TRANSFERRING) {
                        IconButton(onClick = onPauseClick, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Pause, contentDescription = "Pause", tint = BentoAccentLavender, modifier = Modifier.size(18.dp))
                        }
                    } else if (transfer.status == TransferStatus.PAUSED || transfer.status == TransferStatus.FAILED) {
                        IconButton(onClick = onResumeClick, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Resume", tint = BentoMintGreen, modifier = Modifier.size(18.dp))
                        }
                    }

                    if (transfer.status != TransferStatus.COMPLETED && transfer.status != TransferStatus.CANCELLED) {
                        IconButton(onClick = onCancelClick, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel", tint = TextMuted, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            if (transfer.status == TransferStatus.TRANSFERRING || transfer.status == TransferStatus.PAUSED) {
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { transfer.progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (transfer.status == TransferStatus.PAUSED) BentoAccentLavender.copy(alpha = 0.5f) else BentoAccentLavender,
                    trackColor = BentoCardBorder
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (transfer.status == TransferStatus.PAUSED) "Paused" else "${formatBytes(transfer.speedBytesPerSec)}/s",
                        fontSize = 11.sp,
                        color = BentoAccentLavender,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (transfer.status == TransferStatus.PAUSED) "${(transfer.progress * 100).toInt()}%" else "~${transfer.etaSeconds}s remaining",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            } else if (transfer.status == TransferStatus.COMPLETED && !transfer.checksum.isNull_or_Empty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "SHA-256: ${transfer.checksum}",
                    fontSize = 10.sp,
                    color = BentoMintGreen,
                    fontWeight = FontWeight.Medium
                )
            } else if (transfer.status == TransferStatus.FAILED && !transfer.errorMessage.isNull_or_Empty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Error: ${transfer.errorMessage}",
                    fontSize = 10.sp,
                    color = RoseError,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

private fun String?.isNull_or_Empty(): Boolean = this == null || this.trim().isEmpty()

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val exp = (Math.log(bytes.toDouble()) / Math.log(1024.0)).toInt()
    val pre = "KMGTPE"[exp - 1]
    return String.format("%.1f %sB", bytes / Math.pow(1024.0, exp.toDouble()), pre)
}
