package com.localcast.transfer.network.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.util.Log
import com.localcast.transfer.model.Capability
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.DeviceType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.InetAddress

class NsdDiscovery(private val context: Context) {

    private val TAG = "LocalCast/NSD"
    private val SERVICE_TYPE = "_localcast._tcp."
    
    private val nsdManager: NsdManager? =
        context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    private val wifiManager: WifiManager? =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private var multicastLock: WifiManager.MulticastLock? = null
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    private val _discoveredDevices = MutableStateFlow<Map<String, Device>>(emptyMap())
    val discoveredDevices: StateFlow<Map<String, Device>> = _discoveredDevices.asStateFlow()

    private var localServiceName: String? = null

    fun registerService(port: Int, deviceName: String) {
        acquireMulticastLock()
        val serviceInfo = NsdServiceInfo().apply {
            serviceName = deviceName
            serviceType = SERVICE_TYPE
            setPort(port)
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(NsdServiceInfo: NsdServiceInfo) {
                localServiceName = NsdServiceInfo.serviceName
                Log.d(TAG, "NSD Service registered: $localServiceName")
            }

            override fun onRegistrationFailed(arg0: NsdServiceInfo, arg1: Int) {
                Log.e(TAG, "NSD Registration failed: $arg1")
            }

            override fun onServiceUnregistered(arg0: NsdServiceInfo) {
                Log.d(TAG, "NSD Service unregistered: ${arg0.serviceName}")
            }

            override fun onUnregistrationFailed(arg0: NsdServiceInfo, arg1: Int) {
                Log.e(TAG, "NSD Unregistration failed: $arg1")
            }
        }

        try {
            nsdManager?.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register NSD service", e)
        }
    }

    fun startDiscovery() {
        acquireMulticastLock()
        if (discoveryListener != null) {
            stopDiscovery()
        }

        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                Log.d(TAG, "NSD Service discovery started")
            }

            override fun onServiceFound(service: NsdServiceInfo) {
                Log.d(TAG, "NSD Service found: ${service.serviceName}")
                if (service.serviceType.contains("_localcast")) {
                    if (service.serviceName == localServiceName) {
                        return // Ignore self
                    }
                    nsdManager?.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                            Log.e(TAG, "NSD Resolve failed: $errorCode")
                        }

                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            Log.d(TAG, "NSD Service Resolved: ${serviceInfo.serviceName} at ${serviceInfo.host}")
                            val host: InetAddress? = serviceInfo.host
                            val ip = host?.hostAddress ?: return
                            if (ip.startsWith("127.")) return

                            val deviceId = "nsd_${serviceInfo.serviceName.replace(" ", "_")}_${ip.replace(".", "_")}"

                            val device = Device(
                                deviceId = deviceId,
                                deviceName = serviceInfo.serviceName,
                                deviceType = DeviceType.ANDROID,
                                ipAddress = ip,
                                port = serviceInfo.port,
                                capabilities = listOf(
                                    Capability.FILE_TRANSFER,
                                    Capability.VIDEO_STREAM,
                                    Capability.PHOTO_STREAM
                                )
                            )

                            val currentMap = _discoveredDevices.value.toMutableMap()
                            currentMap[device.deviceId] = device
                            _discoveredDevices.value = currentMap
                        }
                    })
                }
            }

            override fun onServiceLost(service: NsdServiceInfo) {
                val currentMap = _discoveredDevices.value.toMutableMap()
                val keysToRemove = currentMap.filter { it.value.deviceName == service.serviceName }.keys
                keysToRemove.forEach { currentMap.remove(it) }
                _discoveredDevices.value = currentMap
            }

            override fun onDiscoveryStopped(serviceType: String) {
                Log.i(TAG, "NSD Discovery stopped")
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "NSD Start Discovery failed: $errorCode")
                nsdManager?.stopServiceDiscovery(this)
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "NSD Stop Discovery failed: $errorCode")
            }
        }

        try {
            nsdManager?.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start NSD discovery", e)
        }
    }

    fun stopDiscovery() {
        discoveryListener?.let { listener ->
            try {
                nsdManager?.stopServiceDiscovery(listener)
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping NSD discovery", e)
            }
            discoveryListener = null
        }
        releaseMulticastLock()
    }

    fun unregisterService() {
        registrationListener?.let { listener ->
            try {
                nsdManager?.unregisterService(listener)
            } catch (e: Exception) {
                Log.e(TAG, "Error unregistering NSD service", e)
            }
            registrationListener = null
        }
        releaseMulticastLock()
    }

    private fun acquireMulticastLock() {
        if (multicastLock == null) {
            multicastLock = wifiManager?.createMulticastLock("LocalCastMulticastLock")?.apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseMulticastLock() {
        multicastLock?.let {
            if (it.isHeld) {
                it.release()
            }
        }
        multicastLock = null
    }
}
