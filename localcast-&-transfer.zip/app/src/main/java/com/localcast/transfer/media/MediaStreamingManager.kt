package com.localcast.transfer.media

import android.content.Context
import android.net.Uri
import com.localcast.transfer.model.CastingMediaItem
import com.localcast.transfer.model.CastingSession
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.PlaybackControlCommand
import com.localcast.transfer.network.discovery.NetworkInfoProvider
import com.localcast.transfer.network.server.LocalHttpServer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

class MediaStreamingManager(
    private val context: Context,
    private val httpServerProvider: () -> LocalHttpServer,
    private val networkInfoProvider: NetworkInfoProvider
) {
    private val _castingSession = MutableStateFlow(CastingSession())
    val castingSession: StateFlow<CastingSession> = _castingSession.asStateFlow()

    fun startCasting(mediaItem: CastingMediaItem, targetDevice: Device, file: File? = null, uri: Uri? = null) {
        val path = httpServerProvider().registerMedia(mediaItem, file, uri)
        val localIp = networkInfoProvider.getNetworkStatus().ipAddress
        val fullStreamUrl = "http://$localIp:8765$path"

        _castingSession.value = CastingSession(
            isCasting = true,
            currentItem = mediaItem,
            targetDevice = targetDevice,
            isPlaying = true,
            currentPositionMs = 0L,
            streamUrl = fullStreamUrl,
            volume = 1.0f
        )
    }

    fun handleRemoteControl(command: PlaybackControlCommand, positionMs: Long, volume: Float) {
        _castingSession.update { current ->
            if (!current.isCasting) return@update current
            when (command) {
                PlaybackControlCommand.PLAY -> current.copy(isPlaying = true)
                PlaybackControlCommand.PAUSE -> current.copy(isPlaying = false)
                PlaybackControlCommand.STOP -> CastingSession()
                PlaybackControlCommand.SEEK -> current.copy(currentPositionMs = positionMs)
                PlaybackControlCommand.VOLUME -> current.copy(volume = volume)
            }
        }
    }

    fun setPlaying(playing: Boolean) {
        _castingSession.update { it.copy(isPlaying = playing) }
    }

    fun updatePosition(posMs: Long) {
        _castingSession.update { it.copy(currentPositionMs = posMs) }
    }

    fun updateVolume(vol: Float) {
        _castingSession.update { it.copy(volume = vol) }
    }

    fun stopCasting() {
        val current = _castingSession.value
        if (current.currentItem != null) {
            httpServerProvider().unregisterMedia(current.currentItem.id)
        }
        _castingSession.value = CastingSession()
    }
}

