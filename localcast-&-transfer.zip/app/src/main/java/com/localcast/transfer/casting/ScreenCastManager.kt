package com.localcast.transfer.casting

import android.content.Context
import com.localcast.transfer.network.server.LocalHttpServer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ScreenCastStatus {
    STOPPED
}

class ScreenCastManager(
    private val context: Context,
    private val httpServer: LocalHttpServer
) {
    private val _isScreenCasting = MutableStateFlow(false)
    val isScreenCasting: StateFlow<Boolean> = _isScreenCasting.asStateFlow()

    private val _status = MutableStateFlow(ScreenCastStatus.STOPPED)
    val status: StateFlow<ScreenCastStatus> = _status.asStateFlow()

    fun stopScreenCast() {
        _isScreenCasting.value = false
        _status.value = ScreenCastStatus.STOPPED
    }
}
