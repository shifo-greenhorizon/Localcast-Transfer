package com.localcast.transfer.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS paired_devices_new (
                deviceId TEXT NOT NULL PRIMARY KEY,
                deviceName TEXT NOT NULL,
                deviceType TEXT NOT NULL,
                ipAddress TEXT NOT NULL,
                port INTEGER NOT NULL,
                isTrusted INTEGER NOT NULL,
                lastConnectedTimestamp INTEGER NOT NULL
            )
        """.trimIndent())
        
        db.execSQL("""
            INSERT INTO paired_devices_new (deviceId, deviceName, deviceType, ipAddress, port, isTrusted, lastConnectedTimestamp)
            SELECT deviceId, deviceName, deviceType, ipAddress, port, isTrusted, lastConnectedTimestamp
            FROM paired_devices
        """.trimIndent())
        
        db.execSQL("DROP TABLE paired_devices")
        db.execSQL("ALTER TABLE paired_devices_new RENAME TO paired_devices")
    }
}

@Database(
    entities = [TransferEntity::class, PairedDeviceEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transferDao(): TransferDao
    abstract fun pairedDeviceDao(): PairedDeviceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "localcast_db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
