package com.localcast.transfer.network.discovery

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import com.localcast.transfer.model.NetworkStatus
import java.net.Inet4Address
import java.net.NetworkInterface

class NetworkInfoProvider(private val context: Context) {

    fun getNetworkStatus(): NetworkStatus {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val wifiManager =
            context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

        var isWifiConnected = false
        var isHotspotActive = false
        var ipAddress = "127.0.0.1"
        var ssid = "Disconnected"
        var interfaceName = "wlan0"

        connectivityManager?.let { cm ->
            val activeNetwork = cm.activeNetwork
            val capabilities = cm.getNetworkCapabilities(activeNetwork)
            val linkProperties = cm.getLinkProperties(activeNetwork)

            if (capabilities != null) {
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    isWifiConnected = true
                    val wifiInfo = wifiManager?.connectionInfo
                    if (wifiInfo != null && wifiInfo.ssid != null && wifiInfo.ssid != "<unknown ssid>") {
                        ssid = wifiInfo.ssid.replace("\"", "")
                    } else {
                        ssid = "Local Wi-Fi"
                    }
                }
            }

            if (linkProperties != null) {
                for (linkAddr in linkProperties.linkAddresses) {
                    val addr = linkAddr.address
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val host = addr.hostAddress
                        if (host != null && !host.startsWith("127.")) {
                            ipAddress = host
                            interfaceName = linkProperties.interfaceName ?: "active"
                            break
                        }
                    }
                }
            }
        }

        // Fallback to active network interfaces if activeNetwork link properties did not yield IP
        if (ipAddress == "127.0.0.1") {
            val localIp = getLocalIPv4Address()
            if (localIp != null) {
                ipAddress = localIp.first
                interfaceName = localIp.second
                if (!isWifiConnected) {
                    isHotspotActive = true
                    ssid = "Local AP / Hotspot"
                }
            }
        }

        val isLocalNetworkReady = (isWifiConnected || isHotspotActive || ipAddress != "127.0.0.1")

        return NetworkStatus(
            isWifiConnected = isWifiConnected,
            isHotspotActive = isHotspotActive,
            ipAddress = ipAddress,
            ssid = ssid,
            interfaceName = interfaceName,
            isLocalNetworkReady = isLocalNetworkReady
        )
    }

    private fun getLocalIPv4Address(): Pair<String, String>? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        val hostAddress = address.hostAddress
                        if (hostAddress != null && !hostAddress.startsWith("127.")) {
                            return Pair(hostAddress, networkInterface.name)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore
        }
        return null
    }
}
