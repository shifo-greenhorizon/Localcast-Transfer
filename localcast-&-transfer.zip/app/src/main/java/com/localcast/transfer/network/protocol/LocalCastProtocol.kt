package com.localcast.transfer.network.protocol

import com.localcast.transfer.model.Capability
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.DeviceType
import com.localcast.transfer.model.PlaybackControlCommand
import com.localcast.transfer.model.ReceiverPlaybackState
import org.json.JSONArray
import org.json.JSONObject

data class ProtocolMessage(
    val type: String,
    val protocolVersion: Int = 1,
    val deviceId: String = "",
    val deviceName: String = "",
    val deviceType: String = DeviceType.ANDROID.name,
    val payload: JSONObject = JSONObject()
)

object LocalCastProtocol {
    const val PROTOCOL_VERSION = 1
    const val DEFAULT_PORT = 8765

    // Message Types
    const val TYPE_HELLO = "HELLO"
    const val TYPE_DEVICE_INFO = "DEVICE_INFO"
    const val TYPE_PAIR_REQUEST = "PAIR_REQUEST"
    const val TYPE_PAIR_CHALLENGE = "PAIR_CHALLENGE"
    const val TYPE_PAIR_VERIFY = "PAIR_VERIFY"
    const val TYPE_PAIR_RESULT = "PAIR_RESULT"
    const val TYPE_UNPAIR = "UNPAIR"
    const val TYPE_TRANSFER_REQUEST = "TRANSFER_REQUEST"
    const val TYPE_TRANSFER_RESPONSE = "TRANSFER_RESPONSE"
    const val TYPE_TRANSFER_CANCEL = "TRANSFER_CANCEL"
    const val TYPE_CONTROL_COMMAND = "CONTROL_COMMAND"
    const val TYPE_RECEIVER_STATE = "RECEIVER_STATE"

    fun createHelloMessage(device: Device): String {
        val json = JSONObject()
        json.put("type", TYPE_HELLO)
        json.put("protocolVersion", PROTOCOL_VERSION)
        json.put("deviceId", device.deviceId)
        json.put("deviceName", device.deviceName)
        json.put("deviceType", device.deviceType.name)

        val capArray = JSONArray()
        device.capabilities.forEach { capArray.put(it.name) }
        json.put("capabilities", capArray)

        return json.toString()
    }

    fun createDeviceInfoJson(
        device: Device,
        isPaired: Boolean = false,
        activeMediaId: String? = null,
        activeTitle: String? = null,
        activeMime: String? = null,
        playbackState: ReceiverPlaybackState = ReceiverPlaybackState.IDLE
    ): JSONObject {
        return JSONObject().apply {
            put("status", "ok")
            put("type", TYPE_DEVICE_INFO)
            put("protocolVersion", PROTOCOL_VERSION)
            put("deviceId", device.deviceId)
            put("deviceName", device.deviceName)
            put("deviceType", device.deviceType.name)
            put("appVersion", "1.0.0")
            put("port", device.port)
            put("isPaired", isPaired)
            put("receiverState", playbackState.name)
            put("capabilities", JSONArray().apply {
                device.capabilities.forEach { put(it.name) }
            })
            if (!activeMediaId.isNullOrEmpty()) {
                put("activeMediaId", activeMediaId)
                put("activeTitle", activeTitle ?: "")
                put("activeMime", activeMime ?: "")
            }
        }
    }

    fun parseDeviceInfo(json: JSONObject, fallbackIp: String, fallbackPort: Int): Device? {
        return try {
            val protocolVer = json.optInt("protocolVersion", 1)
            val deviceId = json.optString("deviceId", "unknown_device")
            val deviceName = json.optString("deviceName", "Receiver Device")
            val rawType = json.optString("deviceType", "ANDROID")
            val deviceType = try {
                DeviceType.valueOf(rawType.uppercase())
            } catch (e: Exception) {
                DeviceType.WEB_RECEIVER
            }
            val isPaired = json.optBoolean("isPaired", false)
            val port = json.optInt("port", fallbackPort)

            val caps = mutableListOf<Capability>()
            val capArray = json.optJSONArray("capabilities")
            if (capArray != null) {
                for (i in 0 until capArray.length()) {
                    try {
                        caps.add(Capability.valueOf(capArray.getString(i)))
                    } catch (_: Exception) {}
                }
            }
            if (caps.isEmpty()) {
                caps.addAll(listOf(Capability.FILE_TRANSFER, Capability.VIDEO_STREAM, Capability.PHOTO_STREAM))
            }

            Device(
                deviceId = deviceId,
                deviceName = deviceName,
                deviceType = deviceType,
                ipAddress = fallbackIp,
                port = port,
                capabilities = caps,
                protocolVersion = protocolVer,
                isPaired = isPaired
            )
        } catch (e: Exception) {
            null
        }
    }

    fun createPairRequestJson(
        senderDeviceId: String,
        senderName: String,
        senderDeviceType: String = DeviceType.ANDROID.name
    ): JSONObject {
        return JSONObject().apply {
            put("type", TYPE_PAIR_REQUEST)
            put("protocolVersion", PROTOCOL_VERSION)
            put("deviceId", senderDeviceId)
            put("deviceName", senderName)
            put("deviceType", senderDeviceType)
        }
    }

    fun createPairVerifyJson(
        sessionId: String,
        pin: String,
        senderDeviceId: String,
        senderName: String
    ): JSONObject {
        return JSONObject().apply {
            put("type", TYPE_PAIR_VERIFY)
            put("protocolVersion", PROTOCOL_VERSION)
            put("sessionId", sessionId)
            put("pin", pin)
            put("deviceId", senderDeviceId)
            put("deviceName", senderName)
        }
    }

    fun createTransferRequestJson(
        transferId: String,
        fileName: String,
        fileSize: Long,
        mimeType: String,
        checksum: String?,
        supportsResume: Boolean = true
    ): JSONObject {
        return JSONObject().apply {
            put("type", TYPE_TRANSFER_REQUEST)
            put("protocolVersion", PROTOCOL_VERSION)
            put("transferId", transferId)
            put("fileName", fileName)
            put("fileSize", fileSize)
            put("mimeType", mimeType)
            put("checksum", checksum ?: "")
            put("supportsResume", supportsResume)
        }
    }

    fun createControlCommandJson(
        command: PlaybackControlCommand,
        positionMs: Long = 0L,
        volume: Float = 1.0f
    ): JSONObject {
        return JSONObject().apply {
            put("type", TYPE_CONTROL_COMMAND)
            put("protocolVersion", PROTOCOL_VERSION)
            put("command", command.name)
            put("positionMs", positionMs)
            put("volume", volume.toDouble())
        }
    }

    fun parseMessage(rawJson: String): ProtocolMessage? {
        return try {
            val json = JSONObject(rawJson)
            val type = json.optString("type", "UNKNOWN")
            val protocolVer = json.optInt("protocolVersion", 1)
            val deviceId = json.optString("deviceId", "unknown")
            val deviceName = json.optString("deviceName", "Unknown Device")
            val deviceType = json.optString("deviceType", DeviceType.ANDROID.name)
            val payload = json.optJSONObject("payload") ?: json

            ProtocolMessage(
                type = type,
                protocolVersion = protocolVer,
                deviceId = deviceId,
                deviceName = deviceName,
                deviceType = deviceType,
                payload = payload
            )
        } catch (e: Exception) {
            null
        }
    }
}

