package com.localcast.transfer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localcast.transfer.model.Device
import com.localcast.transfer.ui.MainUiState
import com.localcast.transfer.ui.NavigationTab
import com.localcast.transfer.ui.components.DeviceItemRow
import com.localcast.transfer.ui.components.LargeSendFilesBentoCard
import com.localcast.transfer.ui.components.NetworkStatusCard
import com.localcast.transfer.ui.components.SmallBentoCard
import com.localcast.transfer.ui.components.WideBentoCard
import com.localcast.transfer.ui.theme.BentoAccentLavender
import com.localcast.transfer.ui.theme.BentoCardBg
import com.localcast.transfer.ui.theme.BentoCardBorder
import com.localcast.transfer.ui.theme.TextMuted
import com.localcast.transfer.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    state: MainUiState,
    onNavigateTab: (NavigationTab) -> Unit,
    onSelectDevice: (Device) -> Unit,
    onPickFiles: () -> Unit,
    onPickMedia: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("home_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            NetworkStatusCard(
                networkStatus = state.networkStatus,
                webReceiverUrl = state.webReceiverUrl,
                onOpenReceiverClick = { onNavigateTab(NavigationTab.SETTINGS) }
            )
        }

        // BENTO GRID CONTAINER
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Large Bento Card: Send Files
                LargeSendFilesBentoCard(
                    onClick = onPickFiles
                )

                // 2-Column Bento Grid Row: Cast Video & Photos
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SmallBentoCard(
                        title = "Cast Video",
                        subtitle = "Local Stream",
                        icon = Icons.Default.Movie,
                        onClick = onPickMedia,
                        modifier = Modifier.weight(1f)
                    )

                    SmallBentoCard(
                        title = "Photos",
                        subtitle = "Sync Gallery",
                        icon = Icons.Default.Image,
                        onClick = onPickMedia,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Wide Bento Card: Cast Player
                WideBentoCard(
                    title = "Media Streaming Player",
                    subtitle = "Stream video/audio to local web player",
                    icon = Icons.Default.Cast,
                    onClick = { onNavigateTab(NavigationTab.CAST) }
                )
            }
        }

        // NEARBY DEVICES TRAY
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "NEARBY DEVICES",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TextSecondary,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = if (state.isDiscovering) "SEARCHING..." else "READY",
                    fontSize = 10.sp,
                    color = BentoAccentLavender,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        if (state.discoveredDevices.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BentoCardBg),
                    border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Scanning local network for devices...",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Ensure receiver devices (TV, PC, phone) are on the same Wi-Fi or Hotspot.",
                            fontSize = 11.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }
            }
        } else {
            items(state.discoveredDevices) { device ->
                DeviceItemRow(
                    device = device,
                    onConnectClick = { onSelectDevice(device) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
