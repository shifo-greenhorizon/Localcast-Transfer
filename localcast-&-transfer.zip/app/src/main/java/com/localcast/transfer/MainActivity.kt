package com.localcast.transfer

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Phonelink
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.localcast.transfer.model.CastingMediaItem
import com.localcast.transfer.model.Device
import com.localcast.transfer.model.DeviceType
import com.localcast.transfer.ui.MainViewModel
import com.localcast.transfer.ui.NavigationTab
import com.localcast.transfer.ui.screens.CastScreen
import com.localcast.transfer.ui.screens.DevicesScreen
import com.localcast.transfer.ui.screens.HomeScreen
import com.localcast.transfer.ui.screens.SettingsScreen
import com.localcast.transfer.ui.screens.TransferScreen
import com.localcast.transfer.ui.theme.BentoAccentLavender
import com.localcast.transfer.ui.theme.BentoCardBg
import com.localcast.transfer.ui.theme.BentoDarkBg
import com.localcast.transfer.ui.theme.BentoDarkPurple
import com.localcast.transfer.ui.theme.LocalCastTheme
import com.localcast.transfer.ui.theme.TextMuted
import com.localcast.transfer.ui.theme.TextPrimary
import java.util.UUID

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            LocalCastTheme {
                LocalCastApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun LocalCastApp(viewModel: MainViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // System Permissions Launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    LaunchedEffect(Unit) {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissionsLauncher.launch(permissions.toTypedArray())
    }

    LaunchedEffect(state.statusMessage) {
        state.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Pick files for transfer launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val targetDevice = state.selectedDevice ?: state.discoveredDevices.firstOrNull()
            if (targetDevice != null) {
                uris.forEach { uri ->
                    val (fileName, fileSize) = getUriFileInfo(context, uri)
                    viewModel.startFileTransfer(
                        device = targetDevice,
                        fileName = fileName,
                        fileSize = fileSize,
                        mimeType = context.contentResolver.getType(uri) ?: "application/octet-stream",
                        uriString = uri.toString()
                    )
                }
            } else {
                Toast.makeText(context, "Please select a target device first from Home or Devices tab", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Pick media for casting launcher
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val targetDevice = state.selectedDevice ?: state.discoveredDevices.firstOrNull() ?: Device(
                deviceId = "web_receiver",
                deviceName = "Web Receiver",
                deviceType = DeviceType.WEB_RECEIVER,
                ipAddress = state.networkStatus.ipAddress,
                port = 8765
            )

            val (fileName, fileSize) = getUriFileInfo(context, uri)
            val mime = context.contentResolver.getType(uri) ?: "video/mp4"

            val mediaItem = CastingMediaItem(
                id = UUID.randomUUID().toString(),
                title = fileName,
                uriString = uri.toString(),
                mimeType = mime,
                fileSize = fileSize
            )

            viewModel.startCasting(
                mediaItem = mediaItem,
                targetDevice = targetDevice,
                uri = uri
            )
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = BentoDarkBg,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = BentoCardBg,
                contentColor = TextPrimary,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = state.activeTab == NavigationTab.HOME,
                    onClick = { viewModel.setTab(NavigationTab.HOME) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BentoDarkPurple,
                        selectedTextColor = BentoAccentLavender,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = BentoAccentLavender
                    ),
                    modifier = Modifier.testTag("nav_item_home")
                )

                NavigationBarItem(
                    selected = state.activeTab == NavigationTab.DEVICES,
                    onClick = { viewModel.setTab(NavigationTab.DEVICES) },
                    icon = { Icon(Icons.Default.Phonelink, contentDescription = "Devices") },
                    label = { Text("Devices", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BentoDarkPurple,
                        selectedTextColor = BentoAccentLavender,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = BentoAccentLavender
                    ),
                    modifier = Modifier.testTag("nav_item_devices")
                )

                NavigationBarItem(
                    selected = state.activeTab == NavigationTab.TRANSFER,
                    onClick = { viewModel.setTab(NavigationTab.TRANSFER) },
                    icon = { Icon(Icons.Default.SwapVert, contentDescription = "Transfer") },
                    label = { Text("Transfers", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BentoDarkPurple,
                        selectedTextColor = BentoAccentLavender,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = BentoAccentLavender
                    ),
                    modifier = Modifier.testTag("nav_item_transfers")
                )

                NavigationBarItem(
                    selected = state.activeTab == NavigationTab.CAST,
                    onClick = { viewModel.setTab(NavigationTab.CAST) },
                    icon = { Icon(Icons.Default.Cast, contentDescription = "Cast") },
                    label = { Text("Cast", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BentoDarkPurple,
                        selectedTextColor = BentoAccentLavender,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = BentoAccentLavender
                    ),
                    modifier = Modifier.testTag("nav_item_cast")
                )

                NavigationBarItem(
                    selected = state.activeTab == NavigationTab.SETTINGS,
                    onClick = { viewModel.setTab(NavigationTab.SETTINGS) },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BentoDarkPurple,
                        selectedTextColor = BentoAccentLavender,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = BentoAccentLavender
                    ),
                    modifier = Modifier.testTag("nav_item_settings")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (state.activeTab) {
                NavigationTab.HOME -> HomeScreen(
                    state = state,
                    onNavigateTab = { viewModel.setTab(it) },
                    onSelectDevice = { viewModel.selectDevice(it) },
                    onPickFiles = { filePickerLauncher.launch("*/*") },
                    onPickMedia = { mediaPickerLauncher.launch("video/*") }
                )
                NavigationTab.DEVICES -> DevicesScreen(
                    state = state,
                    onSelectDevice = { viewModel.selectDevice(it) },
                    onAddManualDevice = { ip, name -> viewModel.addManualDevice(ip, name) }
                )
                NavigationTab.TRANSFER -> TransferScreen(
                    state = state,
                    onPickFilesClick = { filePickerLauncher.launch("*/*") },
                    onPauseTransfer = { viewModel.pauseTransfer(it) },
                    onResumeTransfer = { viewModel.resumeTransfer(it) },
                    onCancelTransfer = { viewModel.cancelTransfer(it) },
                    onClearHistoryClick = { viewModel.clearHistory() }
                )
                NavigationTab.CAST -> CastScreen(
                    state = state,
                    onPickMediaClick = { mediaPickerLauncher.launch("video/*") },
                    onControlCommand = { cmd, pos, vol -> viewModel.sendRemoteControlCommand(cmd, pos, vol) },
                    onStopCastClick = { viewModel.stopCasting() }
                )
                NavigationTab.SETTINGS -> SettingsScreen(
                    state = state
                )
            }
        }
    }
}

private fun getUriFileInfo(context: Context, uri: Uri): Pair<String, Long> {
    var fileName = "file_${System.currentTimeMillis()}"
    var fileSize = 0L

    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (nameIndex != -1) fileName = cursor.getString(nameIndex)
            if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
        }
    }
    return Pair(fileName, fileSize)
}
