package com.localcast.transfer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localcast.transfer.ui.MainUiState
import com.localcast.transfer.ui.components.TransferItemCard
import com.localcast.transfer.ui.theme.BentoAccentLavender
import com.localcast.transfer.ui.theme.BentoCardBg
import com.localcast.transfer.ui.theme.BentoCardBorder
import com.localcast.transfer.ui.theme.BentoDarkPurple
import com.localcast.transfer.ui.theme.TextMuted
import com.localcast.transfer.ui.theme.TextPrimary
import com.localcast.transfer.ui.theme.TextSecondary

@Composable
fun TransferScreen(
    state: MainUiState,
    onPickFilesClick: () -> Unit,
    onPauseTransfer: (String) -> Unit,
    onResumeTransfer: (String) -> Unit,
    onCancelTransfer: (String) -> Unit,
    onClearHistoryClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("transfer_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "File Transfer Center",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = TextPrimary
                )

                IconButton(
                    onClick = onClearHistoryClick,
                    modifier = Modifier.testTag("clear_transfer_history_button")
                ) {
                    Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Clear History", tint = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = onPickFilesClick,
                colors = ButtonDefaults.buttonColors(containerColor = BentoAccentLavender),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("pick_and_send_files_button")
            ) {
                Icon(imageVector = Icons.Default.FileUpload, contentDescription = "Send", tint = BentoDarkPurple)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Select & Send Files", color = BentoDarkPurple, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }

        item {
            Text(
                text = "Transfers & Queue",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = TextPrimary
            )
        }

        if (state.transfers.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = BentoCardBg),
                    border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(BentoCardBorder))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No active or past transfers",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Tap 'Select & Send Files' above or open the Web Receiver on another device to receive files.",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        } else {
            items(state.transfers) { transfer ->
                TransferItemCard(
                    transfer = transfer,
                    onPauseClick = { onPauseTransfer(transfer.id) },
                    onResumeClick = { onResumeTransfer(transfer.id) },
                    onCancelClick = { onCancelTransfer(transfer.id) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
